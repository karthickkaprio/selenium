package array;

import java.util.Arrays;

public class SecondLargest {

	public static void main(String[] args) {
		int[] data= {3,2,11,4,6,7};
		Arrays.sort(data);
	int len=data.length;
		for(int i=0;i<data.length;i++) {
			System.out.println(data[i]);
			}
		System.out.println("the second largest num="+data[len-2]);

	}

}
