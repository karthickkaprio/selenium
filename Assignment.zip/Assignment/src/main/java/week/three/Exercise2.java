package week.three;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exercise2 {

	public static void main(String[] args) {
		
List<String>companyname=new ArrayList<String>();
companyname.add("HCL");
companyname.add("Wipro");
companyname.add("Aspire Systems");
companyname.add("CTS");
Collections.sort(companyname,Collections.reverseOrder());
	System.out.println(companyname);
}

	}


