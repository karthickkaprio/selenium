package week.three;

public class Students {
	public void getStudentInfo() {
		System.out.println("Student Data");
	}
    public void getStudentInfo(String id) {
	System.out.println(id);
    }
	public void getStudentInfo(String id ,String name) {
		System.out.println(id+" "+name);
		
	}
	public void getStudentInfo(long phone,String email) {
		System.out.println(phone+" "+email);
		
		
	}
	public static void main(String[] args) {
		Students obj=new Students();
		obj.getStudentInfo();
		obj.getStudentInfo("11EC35");
		obj.getStudentInfo("11EC35", "karthick");
		obj.getStudentInfo(8778946739l, "karthickkala93@gmail.com");
	}
	

}
