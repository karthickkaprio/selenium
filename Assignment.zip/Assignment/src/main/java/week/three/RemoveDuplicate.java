package week.three;

public class RemoveDuplicate {

	public static void main(String[] args) {
	 String input="Amazon India";
	 String val1[]=input.split(" ");
	 String use="";
	
	
     for(int i=0;i<val1.length-1;i++) {
    	 String val2=val1[0].concat(val1[1]);
    	 char text1[]=val2.toCharArray();
    	 
    	 for(int j=0;j<text1.length;j++) {
    	  //System.out.print(text1[j]);
    		// if(!use.contains(input.charAt(j))) {
    		//	 use=use+text1[j];
    		 }
    	 }
     }
	}

    		/* {
    			
    		}
    			 System.out.println(use);
    		 //}
*/    	 
    	 
     
	


