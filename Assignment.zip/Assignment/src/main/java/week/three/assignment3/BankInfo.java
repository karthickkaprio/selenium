package week.three.assignment3;

public class BankInfo {
	public void saving() {
		System.out.println("my saving is 50000");
	}
	public void fixed() {
		System.out.println("my fixed amount is 30000");
	}
	public void deposit() {
		System.out.println("my deposit amount is 20000");
	}

}
