package week.three.assignment3;

public class AxisBank extends BankInfo{
	public void deposit() {
		System.out.println("my deposit amount in axis bank is 60000");
	}
	 void oldVersion() {
		fixed();
		saving();
		super.deposit();
	}
	public static void main(String[] args) {
		AxisBank obj=new AxisBank();
		obj.deposit();
		obj.oldVersion();
		
	}

}
