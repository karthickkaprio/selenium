package week.two;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment5 {
//using select class to handle dropdown box
	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement username=driver.findElementById("username");
		username.click();
		username.sendKeys("Demosalesmanager");
		WebElement password=driver.findElementById("password");
		password.click();
		password.sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Create Lead").click();
		WebElement company=driver.findElementById("createLeadForm_companyName");
		company.clear();
		company.sendKeys("Ascent Circuits");
		WebElement firstname=driver.findElementById("createLeadForm_firstName");
		firstname.clear();
		firstname.sendKeys("Karthick");
		WebElement lastname=driver.findElementById("createLeadForm_lastName");
		lastname.clear();
		lastname.sendKeys("N");
		WebElement source=driver.findElementByXPath("//select[@id='createLeadForm_dataSourceId']");
		Select obj =new Select(source);
		obj.selectByVisibleText("Employee");
		WebElement marketing=driver.findElementByXPath("//select[@id='createLeadForm_marketingCampaignId']");
		Select obj1 =new Select(marketing);
		obj1.selectByVisibleText("Pay Per Click Advertising");
		
		WebElement industry=driver.findElementByXPath("//select[@id='createLeadForm_industryEnumId']");
		Select obj2 =new Select(industry);
		//obj2.selectByIndex(15);
		int listbox=obj2.getOptions().size();
		obj2.selectByIndex(listbox-2);
		
		WebElement owner=driver.findElementByXPath("//select[@id='createLeadForm_ownershipEnumId']");
		Select obj3 =new Select(owner);
		obj3.selectByIndex(5);
		WebElement country=driver.findElementByXPath("//select[@id='createLeadForm_generalCountryGeoId']");
		Select obj4 =new Select(country);
		obj4.selectByVisibleText("India");
		driver.findElementByName("submitButton").click();
		WebElement text=driver.findElementById("viewLead_companyName_sp");
	    System.out.println(text.getText());
	}

}
