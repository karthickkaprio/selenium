package week.two;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignmentlink {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://leafground.com/pages/Link.html");
		//driver.findElementByLinkText("Go to Home Page").click();
	
	/*WebElement link2=driver.findElementByPartialLinkText("Find");
		String where=link2.getAttribute("href");
		System.out.println(where);
		link2.click();
		System.out.println(driver.getTitle());
		*/
		
		/*WebElement check=driver.findElementByLinkText("Verify am I broken?");
		check.click();
		driver.getTitle();
		if(driver.getTitle().contains("HTTP Status 404 � Not Found")) {
			System.out.println("i confirm");
		}*/
		//4driver.findElementByLinkText("Go to Home Page").click();
	  WebElement num =driver.findElementByTagName("a");
	  String linknum=num.getTagName();
	  
		
		System.out.println("linknum");
	
		 
		
		
	}

}
