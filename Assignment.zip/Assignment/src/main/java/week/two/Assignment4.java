package week.two;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment4{
//it will duplicate the mail id
	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		WebElement editbox=driver.findElementById("username");
		editbox.click();
		editbox.sendKeys("Demosalesmanager");
		WebElement password=driver.findElementById("password");
		password.click();
		password.sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		//driver.findElementByLinkText("Create Lead").click();

		/*WebElement companyname=driver.findElementById("createLeadForm_companyName");
		companyname.click();
		companyname.sendKeys("karthick");
		WebElement firstname=driver.findElementById("createLeadForm_firstName");
		firstname.click();
		firstname.sendKeys("karthick");
		WebElement lastname=driver.findElementById("createLeadForm_lasttName");
		lastname.click();
		lastname.sendKeys("N");
		WebElement countrycode=driver.findElementById("createLeadForm_primaryPhoneCountryCode");
		countrycode.click();
		countrycode.sendKeys("+91");
		WebElement phonenum=driver.findElementById("createLeadForm_primaryPhoneNumber");
		phonenum.click();
		phonenum.sendKeys("8778946739");
		WebElement email=driver.findElementById("createLeadForm_primaryEmail");
		email.click();
		email.sendKeys("karthickkala93@gmail.com");*/
		
		
		
		driver.findElementByLinkText("Find Leads").click();	
		driver.findElementByXPath("(//span[@class='x-tab-strip-inner']//span)[3]").click();
		WebElement email=driver.findElementByName("emailAddress");
		email.click();
		email.sendKeys("karthickkala93@gmail.com");
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		driver.findElementByLinkText("11140").click();
		WebElement orginal=driver.findElementById("viewLead_companyName_sp");
        System.out.println(orginal.getText());
        driver.findElementByLinkText("Duplicate Lead").click();
        driver.findElementByXPath("//input[@class='smallSubmit']").click();
        WebElement duplicate=driver.findElementById("viewLead_companyName_sp");
        System.out.println(duplicate.getText());
        if (orginal.getText().equals(duplicate.getText())) {
        	System.out.println("i confirm");
        }
        driver.close();
       
       
        }
	}


