package week.two;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignmentbutton {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://leafground.com/pages/Link.html");
		
		//first link click and executing button operation
	driver.findElementByLinkText("Go to Home Page").click();
	/*WebElement button=driver.findElementByXPath("(//div[@id='post-153']//img)[2]");
	button.click();
	//driver.findElementById("home").click();
	org.openqa.selenium.Point num1=driver.findElementById("position").getLocation();
	System.out.println("The value of x and y is="+num1);
	System.out.println(driver.findElementById("color").getCssValue("background-color"));
	
	WebElement size=driver.findElementById("size");
	size.getSize();
	System.out.println("the width and height is="+size.getSize());
	System.out.println(size.getCssValue("background-color"));
	
	driver.findElementById("home").click();
	
	WebElement hyperlink=driver.findElementByXPath("(//div[@id='post-153']//img)[3]");
	hyperlink.click();
	WebElement link2=driver.findElementByLinkText("Find where am supposed to go without clicking me?");
	String where=link2.getAttribute("href");
	System.out.println(where);
	link2.click();
	System.out.println(driver.getTitle());
	
	
	WebElement check=driver.findElementByLinkText("Verify am I broken?");
	check.click();
	driver.getTitle();
	if(driver.getTitle().contains("HTTP Status 404 � Not Found")) {
		System.out.println("i confirm");
	}
	//4driver.findElementByLinkText("Go to Home Page").click();
	5WebElement numb=driver.findElementByLinkText("How many links are available in this page?");
	String expect=numb.getAttribute("href");
	System.out.println(expect);
	driver.findElementByLinkText("Go to Home Page").click();
	*/
	//driver.findElementByXPath("(//div[@id='post-153']//img)[4]").click();
	//driver.findElementByXPath("(//div[@class='large-6 small-12 columns']/img)[1]").click();
    
	
	//WebElement broken=driver.findElementByXPath("(//label[@for='home']/following::img)[2]");
    //broken.click();
   /* String val=broken.getText();
    if(val.equals("Am I Broken Image?")){
    	System.out.println("i conirm");
    }*/
   // WebElement keyboard=driver.findElementByXPath("(//label[@for='position']/following::img)[2]");
    //keyboard.click();
	/*driver.findElementByXPath("(//div[@id='post-153']//img)[5]").click();
	WebElement dropdown1=driver.findElementById("dropdown1");
	Select obj=new Select(dropdown1);
	obj.selectByIndex(1);
	WebElement dropdown2=driver.findElementByName("dropdown2");
	Select obj1=new Select(dropdown2);
	obj1.selectByVisibleText("Selenium");
	WebElement dropdown3=driver.findElementById("dropdown3");
	Select obj2=new Select(dropdown3);
	obj2.selectByValue("1");
	
	WebElement dropdown4=driver.findElementByClassName("dropdown");
	Select obj3=new Select(dropdown4);
	List <WebElement> x=obj3.getOptions();
	System.out.println(x.size());
	
	WebElement dropdown5=driver.findElementByXPath("(//div[@id='contentblock']//select)[5]");
    dropdown5.click();
	dropdown5.sendKeys("Selenium");
	WebElement dropdown6=driver.findElementByXPath("(//div[@id='contentblock']//select)[6]");
	Select obj4=new Select(dropdown6);
	obj4.selectByValue("2");
    
	driver.findElementByXPath("(//div[@id='post-153']//img)[8]").click();
	WebElement table=driver.findElementByXPath("(//div[@id='contentblock']//div)[1]");
   // List <WebElement> row=(List<WebElement>) table.findElement(By.tagName("tr"));	
*/	
	driver.findElementByXPath("(//div[@id='post-153']//img)[10]").click();
	
	WebElement frame=driver.findElementByTagName("iframe");
	driver.switchTo().frame(frame);
	driver.findElementByXPath("//button[@id='Click']").click();
	WebElement frame1=driver.findElementByTagName("iframe");
	driver.switchTo().frame(frame1);
	driver.findElementById("Click1").click();
	
	System.out.println(frame.getSize());
	

	
	}

}
