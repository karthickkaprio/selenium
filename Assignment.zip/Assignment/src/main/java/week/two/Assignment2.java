package week.two;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment2 {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		WebElement editbox=driver.findElementById("username");
		editbox.click();
		editbox.sendKeys("Demosalesmanager");
		WebElement password=driver.findElementById("password");
		password.click();
		password.sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		WebElement dropdown=driver.findElementByXPath("//div[@id='ext-gen320']");
		System.out.println(dropdown.isEnabled());
		//Select obj=new Select(dropdown);
	   // obj.selectByVisibleText("Phone");;
		//driver.findElementByClassName("x-tab-strip-text ").click();
		WebElement firstname=driver.findElementByXPath("//input[@id='ext-gen248']");
		firstname.click();
		firstname.sendKeys("Karthick");
		
		driver.findElementByXPath("//button[@id='ext-gen334']").click();
		
		WebElement dropdown1=driver.findElementByXPath("//div[@id='ext-gen380']");
		System.out.println(dropdown1.isEnabled());
		//WebElement dropdown2=driver.findElementByXPath("//a[@id='ext-gen953']");
		 
		//Select obj=new Select(dropdown2);
		//obj.selectByIndex(0);
		//WebElement dropdown2=driver.findElementByClassName("x-grid3-hd-inner x-grid3-hd-partyId");
		driver.findElementByXPath("//div[@class='x-grid3-hd-inner x-grid3-hd-partyId']");
		//dropdown2.click();
	    //Select obj=new Select(dropdown2);		
		//obj.selectByIndex(2);
		//driver.findElementByXPath("//a[@href='/crmsfa/control/viewLead?partyId=10527']").click();
		driver.findElementByLinkText("10556").click();
		WebElement tittle=driver.findElementById("viewLead_companyName_sp");
		System.out.println(tittle.getText());
		driver.findElementByLinkText("Edit").click();
		WebElement company=driver.findElementByXPath("//input[@id='updateLeadForm_companyName']");
		
		//WebElement company=driver.findElementById("updateLeadForm_companyName");
		company.click();
		company.clear();
		company.sendKeys("Ascent circuits");
		driver.findElementByXPath("//input[@name='submitButton']").click();
		WebElement tittle2=driver.findElementByXPath("//span[@id='viewLead_companyName_sp']");
		System.out.println(tittle2.getText());
		driver.close();
		
		
		

	}

}
