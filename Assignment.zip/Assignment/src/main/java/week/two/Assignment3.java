package week.two;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment3 {
//in this program run first half it will create phone contact
	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		/*driver.get("http://leaftaps.com/opentaps/control/main");
		WebElement editbox=driver.findElementById("username");
		editbox.click();
		editbox.sendKeys("Demosalesmanager");
		WebElement password=driver.findElementById("password");
		password.click();
		password.sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("(//span[@class='x-panel-header-text'])[4]").click();
		WebElement companyname=driver.findElementByXPath("(//input[@name='companyName'])[1]");
		companyname.click();
		companyname.sendKeys("Ascent circuits");
		WebElement firstname =driver.findElementByXPath("(//input[@name='firstName'])[2]");
		firstname.click();
		firstname.sendKeys("karthick");
		
		WebElement lastname =driver.findElementByXPath("(//input[@name='lastName'])[2]");
		lastname.click();
		lastname.sendKeys("N");
		WebElement phonenum =driver.findElementByXPath("(//input[@name='primaryPhoneNumber'])[3]");
		phonenum.click();
		phonenum.sendKeys("5454545454");
		driver.findElementByXPath("//*[@id='ext-gen545']").click();
		*/
	   // driver.close();
		//next half will delete the cteated phone contact from list need to change two things
		driver.get("http://leaftaps.com/opentaps/control/main");
		WebElement editbox1=driver.findElementById("username");
		editbox1.click();
		editbox1.sendKeys("Demosalesmanager");
		WebElement password1=driver.findElementById("password");
		password1.click();
		password1.sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("(//span[@class='x-tab-strip-inner']//span)[2]").click();
		WebElement phone=driver.findElementByXPath("//input[@name='phoneNumber']");
		phone.click();
		phone.sendKeys("5454545454");
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		driver.findElementByLinkText("11228").click();//change the id ater first half run
		WebElement orginal=driver.findElementById("viewLead_companyName_sp");
        System.out.println(orginal.getText());
        driver.findElementByLinkText("Delete").click();
        driver.findElementByLinkText("Find Leads").click();
        driver.findElementByXPath("(//span[@class='x-tab-strip-inner']//span)[1]").click();
		WebElement id=driver.findElementByXPath("//input[@name='id']");
		id.click();
		id.sendKeys("11228");//change the id to search
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		

	}

}
