package week.two;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentRadioButton {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://leafground.com/pages/radio.html");
		WebElement radio1=driver.findElementById("yes");
		System.out.println(radio1.isDisplayed());
		System.out.println(radio1.isSelected());
		radio1.click();
	    WebElement check=driver.findElementByXPath("(//div[@id='contentblock']//input)[4]");
	    
	    String val=check.getAttribute("value");
	    
	    if(val.contains("1")) {
	    	System.out.println("the default selected button = checked");
	    }
	    WebElement one=driver.findElementByXPath("(//div[@id='contentblock']//input)[5]");
	    String equal=one.getAttribute("value");
	    WebElement two=driver.findElementByXPath("(//div[@id='contentblock']//input)[6]");
	    String equal1=two.getAttribute("value");
	    WebElement three=driver.findElementByXPath("(//div[@id='contentblock']//input)[7]");
	    String equal2=three.getAttribute("value");
		switch (equal1)  {
		case "0":
		driver.findElementByXPath("(//div[@id='contentblock']//input)[5]").click();   
			break;
		case "1":
			 WebElement medium=driver.findElementByXPath("(//div[@id='contentblock']//input)[6]");
			    boolean val1=medium.isSelected();
			    System.out.println(val1);
				if(val1=true) {
					System.out.println("the age group you are is already selected");
				}
				else {
					medium.click();
				}
				break;
		default:
			driver.findElementByXPath("(//div[@id='contentblock']//input)[7]").click();
			break;
		
	}
	}
}
