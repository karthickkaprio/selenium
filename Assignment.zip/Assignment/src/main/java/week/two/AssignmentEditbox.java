package week.two;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentEditbox {

	

	public static void main(String[] args) {
		
	
		//complete 4 activity in button page
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("http://leafground.com/pages/Edit.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement box1 = driver.findElementByXPath("(//div[@class='row']//input)[1]");
	    box1.isDisplayed();
		box1.isEnabled();
		box1.click();
		box1.sendKeys("Karthickkala93@gmail.com");
		//System.out.println(driver.findElementByName("username").getAttribute("value"));
       WebElement box2=driver.findElementByXPath("(//div[@class='row']//input)[2]");
       box2.sendKeys("kar,\t");
       WebElement box3=driver.findElementByXPath("(//div[@class='row']//input)[3]");
       System.out.println(box3.isDisplayed());
       System.out.println(box3.isEnabled());
       System.out.println(box3.getAttribute("value"));
       //System.out.println(driver.findElementByName("username").getAttribute("value"));
       WebElement box4=driver.findElementByXPath("(//div[@class='row']//input)[4]");
       System.out.println(box4.isDisplayed());
       System.out.println(box4.isEnabled());
       box4.clear();
       WebElement box5=driver.findElementByXPath("(//div[@class='row']//input)[5]");
       boolean dis=box5.isDisplayed();
       boolean ena= box5.isEnabled();
       if(dis=false) {
    	  System.out.println("the display value is="+dis); 
       }
       else {
    	   System.out.println("the display value is="+dis);
       }
       if(ena=false) {
     	  System.out.println("the enable value is="+ena); 
        }
        else {
     	   System.out.println("the enable value is="+ena);
        }
       //work with link pages
       
	}

}
