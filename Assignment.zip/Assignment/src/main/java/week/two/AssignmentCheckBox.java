package week.two;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentCheckBox {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/checkbox.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("(//div[@id='contentblock']//input)[1]").click();
		driver.findElementByXPath("(//div[@id='contentblock']//input)[4]").click();
		WebElement check=driver.findElementByXPath("(//div[@id='contentblock']//input)[6]");
		boolean check1=check.isSelected();
		
		if(check1=true) {
			System.out.println("the checkbox selenium is selected ="+check1);
		}
		WebElement check2=driver.findElementByXPath("(//div[@id='contentblock']//input)[8]");
		boolean deselect=check2.isSelected();
		System.out.println("the box is already selected="+deselect);
		if(deselect=true) {
	       check2.click();
	       System.out.println("now it is unselected");
		}
		
		driver.findElementByXPath("(//div[@id='contentblock']//input)[9]").click();
		driver.findElementByXPath("(//div[@id='contentblock']//input)[10]").click();
		driver.findElementByXPath("(//div[@id='contentblock']//input)[11]").click();
		driver.findElementByXPath("(//div[@id='contentblock']//input)[12]").click();
		driver.findElementByXPath("(//div[@id='contentblock']//input)[13]").click();
	}
}
