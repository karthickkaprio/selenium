package week.four;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Table {

	public static void main(String[] args) {
	WebDriverManager.firefoxdriver().setup();
	FirefoxDriver driver =new FirefoxDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get("http://leafground.com/pages/table.html");
	WebElement table=driver.findElementById("table_id");
	List<WebElement> rowcount=table.findElements(By.tagName("tr"));
	List<WebElement> columncount=table.findElements(By.tagName("td"));
	System.out.println("Row count="+rowcount.size());
	System.out.println("column count="+columncount.size());
	List<String> celldata=new ArrayList<String>();
	celldata.add(columncount.get(7).getText());
	System.out.println("The progress valu of interact with Element is="+celldata);
	//columncount.get(14).click();
	driver.findElementByXPath("(//input[@name='vital'])[3]").click();
	}

}
