package week.four;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowHandle {

	public static void main(String[] args) throws InterruptedException {
    WebDriverManager.firefoxdriver().setup();
    FirefoxDriver driver=new FirefoxDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.get("http://leafground.com/pages/Window.html");
    //String parentwindow=driver.getWindowHandle();
    //System.out.println(driver.getTitle());
    //System.out.println(driver.getCurrentUrl());
    driver.findElementById("home").click();
    Set<String> allwindow=driver.getWindowHandles();
    List<String> list=new ArrayList<String>(); 
    list.addAll(allwindow);
    String childwindow= list.get(1);
    driver.switchTo().window(childwindow);
    Thread.sleep(3000);
    driver.findElementByXPath("(//a[@class='wp-categories-link maxheight'])[2]//img").click();
    //System.out.println(driver.getTitle());
    driver.close();
    
    driver.switchTo().window(list.get(0));
    
    driver.findElementByXPath("//label[@for='position']/following-sibling::button").click();
    Set<String> numofwindow=driver.getWindowHandles();
    List<String> list1=new ArrayList<String>();
    list1.addAll(numofwindow);
    System.out.println(list1.size());
    driver.switchTo().window(list1.get(2));
    driver.close();
    driver.switchTo().window(list1.get(0));
    driver.switchTo().window(list1.get(1));
    driver.close();
    driver.switchTo().window(list1.get(0));
    driver.findElementByXPath("(//label[@for='position']/following-sibling::button)[1]").click();
    
    driver.switchTo().window(list1.get(0));
    
    driver.findElementByXPath("(//label[@for='position']/following-sibling::button)[2]").click();
    Thread.sleep(5000);
    Set<String> lastbutton=driver.getWindowHandles();
    List<String> waitwindow=new ArrayList<String>();
    waitwindow.addAll(lastbutton);
    
    driver.switchTo().window(waitwindow.get(2));
    driver.close();
    driver.switchTo().window(waitwindow.get(0));
    driver.switchTo().window(waitwindow.get(1));
    driver.close();
    driver.switchTo().window(waitwindow.get(0));
    driver.close();
    	
    }
    /*ListIterator<String> wall=list1.listIterator();
    
    while(wall.hasNext()) {
    	
    	//System.out.println(wall.next());
    	}*/
    /*for(String num:list1) {
    	System.out.println(num.length());
    }*/
    
    
    
    
    
    
    
    

	}


