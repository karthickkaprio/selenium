package week.four;


import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ZoomCarsUsingMapInterface {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver =new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("http://demo.automationtesting.in/WebTable.html");
       
        WebElement table=driver.findElementByXPath("//div[@class='ui-grid-canvas']");
       
       List<WebElement> cellcount1=table.findElements(By.xpath("//div[@class='ui-grid-cell-contents ng-binding ng-scope']"));
       int num1=cellcount1.size();
        
        
        
        //List<WebElement> rowcount=table.findElements(By.xpath("//div[@class='ui-grid-row ng-scope']"));
        //int num=rowcount.size();
        //System.out.println(num);
        Map<String,String> demo=new LinkedHashMap<String,String>();
       // List<String> list=new ArrayList<String>();
        for(int i=0;i<num1-1;i++) {
       // List<WebElement> celldatavalue=driver.findElements(By.xpath("//div[@class='ui-grid-cell-contents ng-binding ng-scope']"));
        String val=cellcount1.get(i).getText();
        String val1=cellcount1.get(i+1).getText();
        i+=4;
        demo.put(val, val1);
        }
        Set<Entry<String, String>> num2 = demo.entrySet();
        for(Entry<String,String> demo1:num2) {
        System.out.println("Email="+demo1.getKey()+"       "+"Name="+demo1.getValue());
        }
        
	}
}

