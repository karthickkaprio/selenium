package week.four;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Sortable {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://jqueryui.com/sortable/");
		WebElement box=driver.findElementByClassName("demo-frame");
		driver.switchTo().frame(box);
		WebElement item1=driver.findElementByXPath("//li[text()='Item 1']");
		
		WebElement item4=driver.findElementByXPath("//li[text()='Item 4']");
		WebElement item5=driver.findElementByXPath("//li[text()='Item 5']");
		
		int x=item4.getLocation().getX();
		int y=item5.getLocation().getY();
		Actions builder=new Actions(driver);
		builder.dragAndDropBy(item1, x, y).perform();
		

	}

}
