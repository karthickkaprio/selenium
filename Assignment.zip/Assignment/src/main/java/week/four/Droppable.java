package week.four;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Droppable {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "C:\\Users\\hp\\Downloads\\driver\\geckodriver_32 bit.exe");
    WebDriver driver=new FirefoxDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.get("https://jqueryui.com/droppable/");
    WebElement box=driver.findElement(By.className("demo-frame"));
    driver.switchTo().frame(box);
    WebElement moveableitem=driver.findElement(By.id("draggable"));
    WebElement storageitem=driver.findElement(By.id("droppable"));
    Actions builder=new Actions(driver);
    builder.dragAndDrop(moveableitem, storageitem).perform();
    
    
	}

}
