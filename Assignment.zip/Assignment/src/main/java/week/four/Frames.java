package week.four;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Frames {

	public static void main(String[] args) {
	 WebDriverManager.firefoxdriver().setup();
	 FirefoxDriver driver=new FirefoxDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 driver.get("http://leafground.com/pages/frame.html");
	 WebElement eleframe=driver.findElementByXPath("(//div[@id='wrapframe']/iframe)[1]");
	 driver.switchTo().frame(eleframe);
	 driver.findElementByXPath("//button[@id='Click']").click();
	 driver.switchTo().defaultContent();
	 WebElement eleframe2=driver.findElementByXPath("(//div[@id='wrapframe']/iframe)[2]");
	 driver.switchTo().frame(eleframe2);
	 WebElement element3=driver.findElementById("frame2");
	 driver.switchTo().frame(element3);
	 driver.findElementByXPath("//button[@id='Click1']").click();
	 driver.switchTo().defaultContent();
	 
	 List<String> allframe=new ArrayList<>();
	 String val=driver.findElementByTagName("iframe").getTagName();
	 //System.out.println(val.getSize());
	 allframe.add(val);
	
	 for(String val1:allframe) {
	 System.out.println(val1.length());
	 }
	 }
}


