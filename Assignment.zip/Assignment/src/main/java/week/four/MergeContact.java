package week.four;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MergeContact {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
        FirefoxDriver driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("http://leaftaps.com/opentaps/control/login");
        WebElement username=driver.findElementById("username");
        username.clear();
        username.sendKeys("Demosalesmanager");
        WebElement password=driver.findElementById("password");
        password.clear();
        password.sendKeys("crmsfa");
        driver.findElementByClassName("decorativeSubmit").click();
        driver.findElementByLinkText("CRM/SFA").click();
        driver.findElementByLinkText("Contacts").click();
        driver.findElementByXPath("//a[text()='Merge Contacts']").click();
        System.out.println(driver.getTitle());
        System.out.println(driver.getCurrentUrl());
        String currentwindow=driver.getWindowHandle();
        driver.findElementByXPath("(//input[@id='partyIdFrom']/following::img)[1]").click();
        System.out.println(driver.getTitle());
        System.out.println(driver.getCurrentUrl());
        Set<String> allwindows=driver.getWindowHandles();
        List<String> listofwindow=new ArrayList<String>();
        listofwindow.addAll(allwindows);
        String childwindow=listofwindow.get(1);
        driver.switchTo().window(childwindow);
        Thread.sleep(3000);
        driver.findElementByLinkText("DemoCustomer").click();
       // WebDriverWait wait=new WebDriverWait(driver,timeoutInseconds)
        
         driver.switchTo().window(currentwindow);
        
        driver.findElementByXPath("(//input[@id='partyIdFrom']/following::img)[2]").click();
        Set<String> allwindows1=driver.getWindowHandles();
        List<String> listofwindow1=new ArrayList<String>();
        listofwindow1.addAll(allwindows1);
        String childwindow1=listofwindow1.get(1);
        driver.switchTo().window(childwindow1);
        driver.findElementByLinkText("DemoLBCust").click();
       
        driver.switchTo().window(currentwindow);
        
        driver.findElementByXPath("//a[text()='Merge']").click();
        
        
        driver.switchTo().alert().getText();
        driver.switchTo().alert().accept();
        
        driver.getTitle();
        
        
        
	}

}
