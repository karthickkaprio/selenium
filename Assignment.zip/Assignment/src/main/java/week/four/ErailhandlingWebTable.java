package week.four;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ErailhandlingWebTable {

	public static void main(String[] args) throws InterruptedException {
	WebDriverManager.firefoxdriver().setup();
	FirefoxDriver driver=new FirefoxDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get("https://erail.in/");
	WebElement from=driver.findElementById("txtStationFrom");
	from.clear();
	from.sendKeys("MS");
	from.sendKeys(Keys.ENTER);
	WebElement to=driver.findElementById("txtStationTo");
	to.clear();
	to.sendKeys("TEN");
	to.sendKeys(Keys.ENTER);
	driver.findElementById("chkSelectDateOnly").click();
	Thread.sleep(3000);
	WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']");
    
    List<WebElement> rowcount= table.findElements(By.tagName("tr"));
    List<String> check=new ArrayList<String>();
    for(WebElement rowvalue:rowcount) {
    	List<WebElement> columndata=rowvalue.findElements(By.tagName("td"));
    	//System.out.println(columndata.get(0).getText()+"  "+columndata.get(1).getText());
       // check.add(columndata.get(0).getText());
        check.add(columndata.get(1).getText());
       }
    Collections.sort(check);
    System.out.println(check);
	}
	}


