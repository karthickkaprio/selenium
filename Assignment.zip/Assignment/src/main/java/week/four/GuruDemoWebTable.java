package week.four;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GuruDemoWebTable {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver =new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://demo.guru99.com/test/web-table-element.php#");
		List<WebElement> table=driver.findElementsByXPath("//table[@class='dataTable']//tbody/tr");
		//System.out.println(table.size());
		//List<String> list=new ArrayList<String>();
		Map<String,String> map=new LinkedHashMap<String,String>();
		
		for(int i=1;i<table.size();i++) {
		List<WebElement> val1=driver.findElementsByXPath("//table[@class='dataTable']//tbody/tr["+i+"]/td");
		String data=val1.get(0).getText();
		String data1=val1.get(2).getText();
		map.put(data,data1);
		}
		
		Set<Entry<String,String>> sample= map.entrySet();
		for(Entry<String,String> sample1:sample) {
		System.out.println(sample1.getKey()+"  "+sample1.getValue());	
		}

	}
	}

