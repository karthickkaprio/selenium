package week.four;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Calender {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://leafground.com/pages/Calendar.html");
		driver.findElementById("datepicker").click();
		//WebElement next=driver.findElementByXPath("//a[@class='ui-datepicker-next ui-corner-all']/span");
		//next.click();
		WebElement table= driver.findElementByXPath("//table[@class='ui-datepicker-calendar']");
		List<WebElement> tablerow=table.findElements(By.tagName("tr"));
		System.out.println(tablerow.size());
		
		//List<String> list=new ArrayList<String>();
	    List<WebElement> cellcount=driver.findElementsByTagName("td");
		System.out.println(cellcount.size());
		System.out.println("Today's date is:"+" "+cellcount.get(5).getText());
		cellcount.get(11).click();
 
		
		}
}


