package week.four;

import org.apache.hc.core5.util.Timeout;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExplicitwaitElementAppear {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/appear.html");
		WebDriverWait wait=new WebDriverWait(driver,Timeout.ONE_MILLISECOND.toSeconds());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("btn")));
		//Thread.sleep(3000);
        String lastbuttontext=driver.findElementByXPath("//button[@id='btn']/b").getText();
        System.out.println(lastbuttontext);
       // List<WebElement> val=new ArrayList<WebElement>();
        //val.addAll(lastbuttontext);
       
        	
        }
	}


