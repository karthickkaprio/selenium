package week.four;

import org.apache.hc.core5.util.Timeout;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExplicitwaitDissappear {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/disapper.html");
		WebDriverWait wait = new WebDriverWait(driver, Timeout.ONE_MILLISECOND.toSeconds());
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[@id='btn']/b")));
        String val=driver.findElementByXPath("//div[@id='show']//strong").getText();
        System.out.println(val);
	}

}
