package week.one;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class InterviewPreparation {

	public static void main(String[] args) throws IOException, InterruptedException {
		/*WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("");*/
		/*Thread.sleep(2000);
		File src=driver.getScreenshotAs(OutputType.FILE);
        File tar=new File("./snaps/output.png");
        FileUtils.copyFile(src, tar);
	*/

	/*XSSFWorkbook wb=new XSSFWorkbook("./Exceldata/interviewpreparation.xlsx");
	XSSFSheet sheet=wb.getSheet("sheet1");
	for(int i=0;i<=4;i++) {
	 XSSFRow row=sheet.getRow(i);
	 for(int j=0;j<=2;j++) {
	 XSSFCell cell=row.getCell(j);
	 System.out.println(cell.getStringCellValue());
	   }
	}
	
	int rowscount=sheet.getLastRowNum();
	 System.out.println(rowscount);
	 int cellcount=sheet.getRow(0).getLastCellNum();
	 System.out.println(cellcount);
	
	 String[][] data=new String [rowscount][cellcount];
	 
	for(int i=1;i<=rowscount;i++) {
		for(int j=0;j<cellcount;j++) {
			String val=sheet.getRow(i).getCell(j).getStringCellValue();
			System.out.println(val);
			data[i-1][j]=val;
		}
	}
	wb.close();
	//return data;
*/	
		/*//primenumnber
		int input=4;
		boolean flag=false;
		for(int i=2;i<=input;i++) {
			if(input%2==0) {
				flag=true;
				break;
			}i++;
		}
		if(flag==true)
			System.out.println("not prime");
		else
			System.out.println("prime");
		*/
		
		/*driver.findElementByXPath("//input[@id='identifierId']").sendKeys("karthickkala93@gmail.com");
		Thread.sleep(1000);
		driver.findElementByXPath("//div[@class='VfPpkd-RLmnJb']").click();
		Thread.sleep(2000);
		
		driver.findElementByXPath("//input[@name='password']").sendKeys("security2018");
		Thread.sleep(1000);
		driver.findElementByXPath("(//div[@class='VfPpkd-RLmnJb'])[1]").click();
		*/
		
		
		 int[] a = {1,2,2,3,4,4,5,5,6,7};
		 int []b= new int[a.length];
				
		 for(int i=0;i<=a.length-1;i++) {
        	 //System.out.print(a[i]);
        	 for(int j=i+1;j<a.length;j++) 
        	 {
        		 if(a[i]==a[j]) 
        		 {
        	   System.out.println(a[i]);
        		 }
        		 if(a[i]!=a[j]) {
        			 
        		 }
        		 }
        	 }
		
}
}

