package week.one;

public class ArmStrong {
public static void main(String[] args) {
	
	int num=153,sum=0,rem;
	int org=num;
	
	
	while (num>0) {
		
		rem=num%10;
	    sum=sum+(rem*rem*rem);
		num=num/10;
	    System.out.println(sum);
	    
	}
	    if(org==sum) {
			System.out.println("it is armstrong");
	}
	    else {
	    	System.out.println("not armstrong");
	    }
	
}
}




