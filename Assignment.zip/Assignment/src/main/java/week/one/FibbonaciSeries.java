package week.one;

public class FibbonaciSeries {

	
	public static void main(String[] args) {
	
		int range=8,firstnum=0,secondnum=1;
	
		
		
		for (int i=1; i <= range; i++) {
			
			System.out.println(firstnum);
		    int sum=firstnum+secondnum;
		    firstnum=secondnum;
		    secondnum=sum;
		    
		    
			
			
		}
}
}