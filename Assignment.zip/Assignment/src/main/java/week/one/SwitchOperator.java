package week.one;

public class SwitchOperator {

	public static void main(String[] args) {
		int num1=2,num2=3,res;
	    String val="add";
       switch (val ) {
	case "add":
		res=num1+num2;
		System.out.println("added value="+res);
		break;
    case "sub":
    	res=num1-num2;
		System.out.println("subtracted value="+res);
		break;
    case "mul":
	    res=num1*num2;
	    System.out.println("multiplied value="+res);
	break;
    case "div":
    	res=num1/num2;
    	System.out.println("divided value="+res);
		break;
	default:
	    System.out.println("do you want to perform some other operation");
		break;
	}
	}

}
