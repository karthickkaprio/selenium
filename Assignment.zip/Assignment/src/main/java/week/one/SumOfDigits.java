package week.one;

public class SumOfDigits {

	public static void main(String[] args) {
		int input=999,rem;
		int sum=0;//for performing addition keep sum value =0 always
		while(input>0) {
			rem=input%10;
			sum=sum+rem;
			//System.out.println(sum);
			input=input/10;
			//System.out.println(input);
		}
		System.out.println(sum);
	}
}