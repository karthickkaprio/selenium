package week.one;

public class PrimeNumber {

	public static void main(String[] args) {
		int input=5;
		boolean flag = false;
 
        for(int i=2;i<=input;i++) {
        	//input=input%i;
      // System.out.println(input);
        	
        	if(input%i==0) {
        	flag=true;
        
        	System.out.println(flag);
        	break;
        	}i++;
        }
if(flag==true) {
	System.out.println("not prime");
      }
else if(flag==false) {
	System.out.println(" prime");
}
}
}





