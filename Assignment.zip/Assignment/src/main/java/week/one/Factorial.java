package week.one;

public class Factorial {

	public static void main(String[] args) {
		int input=6,fact=1;//for performing multiplication keep the variable value =1 always
		for (int i = 1; i <= input; i++) {
			fact=fact*i;
			}
		System.out.println(fact);
	}

}
