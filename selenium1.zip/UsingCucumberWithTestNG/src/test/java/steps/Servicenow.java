package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Servicenow {
	public ChromeDriver driver;
   // public static String Incidentnum;
	
	@Given("Launch the Chrome BrowserS")
	public void launchTheChromeBrowserS() {
	   WebDriverManager.chromedriver().setup();
	   driver=new ChromeDriver();
	   driver.manage().window().maximize();
	}

	@Given("Load servicenow Application url (.*)")
	public void loadServicenowApplicationUrl(String URL) {
	   driver.get(URL);
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   }

	@Given("Enter username as (.*)")
	public void enterUsernameAs(String name) {
	   WebElement eleframe=driver.findElementById("gsft_main");
	   driver.switchTo().frame(eleframe);
	   driver.findElementByXPath("//input[@id='user_name']").sendKeys(name); 
	}

	@Given("Enter password as (.*)")
	public void enterPasswordAs(String pword) {
	   driver.findElementByXPath("//input[@id='user_password']").sendKeys(pword);
	}

	@When("Click Login")
	public void clickLogin() {
	   driver.findElementByName("not_important").click();
	}

	@Then("Servicenow HomePage Should be Displayed")
	public void servicenowHomePageShouldBeDisplayed() {
	   System.out.println(driver.getTitle());
	}

	@When("Search Filter Navigator (.*)")
	public void searchFilterNavigator(String val) {
	    driver.findElementByXPath("//input[@id='filter']").sendKeys(val);
	}

	@When("Click All")
	public void clickAll() {
	    driver.findElementByXPath("(//div[text()='All'])[2]").click();
	}

	@When("Click New Button")
	public void clickNewButton() {
	   WebElement eleframe1=driver.findElementByXPath("//iframe[@id='gsft_main']");
	   driver.switchTo().frame(eleframe1);
	   driver.findElementByXPath("//button[@id='sysverb_new']").click(); 
	}

	@When("Select a value for caller and Enter value for short description")
	public void selectAValueForCallerAndEnterValueForShortDescription() {
	    driver.findElementByXPath("//input[@id='sys_display.incident.caller_id']").sendKeys("Abel Tuter");
	    driver.findElementByXPath("//input[@id='incident.short_description']").sendKeys("Automation testing");
	}
	
	String Incidentnum = driver.findElementByXPath("//input[@id='incident.number']").getText();
	@When("Read the incident number and save it to variable")
	public void readTheIncidentNumberAndSaveItToVariable() throws InterruptedException {
        System.out.println(Incidentnum);
		Thread.sleep(2000);
	}

	@When("Click on Submit Button")
	public void clickOnSubmitButton() {
	    driver.findElementByXPath("//button[@name='not_important']").click();
	    }

	@When("Search the same incident number in the next search screeen as below")
	public void searchTheSameIncidentNumberInTheNextSearchScreeenAsBelow() {
        driver.findElementByXPath("(//input[@class='form-control'])[1]").sendKeys(Incidentnum);
	}

	String creatednum=driver.findElementByXPath("//a[@class='linked formlink']").getText();
	@Then("verify the incident is created successful")
	public void verifyTheIncidentIsCreatedSuccessful() {
	if(Incidentnum.equals(creatednum)) {
		  System.out.println("i confirm and created successful");
	  }
	  else {
		  System.out.println("not Successful");
	  }
	}
}
