package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features= {"src/test/java/features/Servicenow.feature"},
                  glue= {"steps"})//dryRun=true,monochrome=true,snippets=SnippetType.CAMELCASE)
public class runServicenow extends AbstractTestNGCucumberTests {
	

}
