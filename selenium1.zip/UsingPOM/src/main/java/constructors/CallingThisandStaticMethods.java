package constructors;

public class CallingThisandStaticMethods{
	
     public static void main(String[] args) {
    	//StaticKeyword sk=new StaticKeyword(300,"kaprio","testleaf");
    	StaticKeyword.name();
		System.out.println(StaticKeyword.compName);
	}
}
