package constructors;

public class ThisKeyword {
	int empid;  //global variable
	String empName; //global varaible
	String compName; //global variable
	
	ThisKeyword(){  //default constructor
		this(100,"karthick","Ascent");//it will go to parameterised constructor and execute the code and come back and execute
		System.out.println("Iam default and i will execute first");
	}
	
	//parameterised constructor with argument
	          //localvariable,//localvariable,//localvariable
	ThisKeyword(int empid,String empName,String compName){
		
		//this();   //it will go to default constructor and execute the code first
		this.empid=empid;  //this is for global variable identification
		this.empName=empName;  
		this.compName=compName;
		
		//System.out.println(empid+empName+compName);
		
	}
	
	public static void main(String[] args) {
		ThisKeyword tk=new ThisKeyword();
		
		System.out.println(tk.empid);
		System.out.println(tk.empName);
		System.out.println(tk.compName);
	}

}
