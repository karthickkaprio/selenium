package constructors;

public class StaticKeyword {
	
	int empid;
	String empName;
	static String compName;//if you make static there will be only one latestcopy
	
	
	 StaticKeyword(){//default constructor
		System.out.println("iam a constructor");
	}
	
	StaticKeyword(int id,String Name,String comp){
		this();//go to default constructor first and execute and come back and execute
		this.empid=id;
		this.empName=Name;
	         compName=comp;//no need to declare as global if you mentioned as static
	}
	public void printValue() {
		System.out.println(empid);
		System.out.println(empName);
		System.out.println(compName);
		}
	
	public static void name() {//if you have method as static 
		System.out.println("iam a static method");
        }

	public static void main(String[] args) {
		//StaticKeyword sk=new StaticKeyword(100,"karthick","Ascent");
		
		StaticKeyword sk1=new StaticKeyword(200,"pandian","softwaresolutions");
		//sk.printValue();
		sk1.printValue();
		StaticKeyword.name();//to call the method classname.methodname
		

	}

}
