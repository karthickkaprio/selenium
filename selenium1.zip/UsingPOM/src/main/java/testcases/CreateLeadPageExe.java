package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Common.ProjectSpecificMethods;
import pages.CreateLead.CreateLeadPage;
import pages.CreateLead.HomePage;
import pages.CreateLead.LoginPage;
import pages.CreateLead.MyHomePage;
import pages.CreateLead.MyLeadsPage;
import pages.CreateLead.ViewLeadPage;

public class CreateLeadPageExe extends ProjectSpecificMethods{
	
	
	@BeforeTest
	public void setFileName() {
		ExcelFile="CredentialsforCreateLead";
	}
	
	@Test(dataProvider="fetchdata")
	public void login(String uName ,String pWord,String cName,
			              String fName,String lName,String phNo) {
	LoginPage lp=new LoginPage(driver);
	lp.enterUsername(uName)
	.enterPassword(pWord)
	.clickLogin();
	
	HomePage hp=new HomePage(driver);
	hp.clickCrmsfa();
	
	MyHomePage mh=new MyHomePage(driver);
	mh.clickLeads();
	
	MyLeadsPage ml=new MyLeadsPage(driver);
	ml.clickCreateLead();
	
	
	CreateLeadPage cp=new CreateLeadPage(driver);
	cp.companyName(cName)
	.firstName(fName)
	.lastName(lName)
	.phoneNumber(phNo)
	.clickSubmit();
	
	

	
	ViewLeadPage vp=new ViewLeadPage(driver);// because ViewLeadpage is changed to static
	vp.verifyLeadFirstname();
	

	
	
	
	}
}
