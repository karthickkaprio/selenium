package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Common.ProjectSpecificMethods;
import pages.EditLead.FindLeadsPageEdit;
import pages.EditLead.HomePageEdit;
import pages.EditLead.LoginPageEdit;
import pages.EditLead.MyHomePageEdit;
import pages.EditLead.MyLeadsPageEdit;
import pages.EditLead.OpentapsPageEdit;
import pages.EditLead.VeriyLeadsPageEdit;
import pages.EditLead.ViewLeadPageEdit;

public class EditLeadPageExe extends ProjectSpecificMethods {
	@BeforeTest
	public void setFileName() {
		ExcelFile ="CredentialsforEditLead";
	}
	
	@Test(dataProvider="fetchdata")
	public void fromLogin(String userN,String passW,String Phno,
			                    String compN,String fName) throws InterruptedException {
		LoginPageEdit le=new LoginPageEdit(driver);
		le.enterUserNameE(userN)
		.enterPasswordE(passW)
		.clickLoginE();
        HomePageEdit hp=new HomePageEdit(driver);
        hp.clickcrmsfa();
        MyHomePageEdit mh=new MyHomePageEdit(driver);
        mh.clickLeads();
        MyLeadsPageEdit ml=new MyLeadsPageEdit(driver);
        ml.clickFindLeads();
        FindLeadsPageEdit fl=new FindLeadsPageEdit(driver);
        fl.clickPhone()
        .enterPhoneNumber(Phno)
        .searchFindLeads()
        .clickFirstResultLead();
        ViewLeadPageEdit vl=new ViewLeadPageEdit(driver);
        vl.clickEdit();
        OpentapsPageEdit op=new OpentapsPageEdit(driver);
        op.changeCompanyName(compN)
        .clickUpdateButton();
        
        VeriyLeadsPageEdit vp=new VeriyLeadsPageEdit(driver);
        vp.enterTheNameEdit(fName)
        .clickOnFindLeadsButtonEdit()
        .checkTheResult();
        
        
       
        
		}

}
