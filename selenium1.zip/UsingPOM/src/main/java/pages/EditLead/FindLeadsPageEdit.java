package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class FindLeadsPageEdit extends ProjectSpecificMethods {
	
	public FindLeadsPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	public FindLeadsPageEdit clickPhone() {
		driver.findElementByXPath("//span[text()='Phone']").click();
		return this;
	}
	public FindLeadsPageEdit enterPhoneNumber(String Phno) {
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys(Phno);
		return this;
	}
	public FindLeadsPageEdit searchFindLeads() throws InterruptedException {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		return this;
    }
	
	public ViewLeadPageEdit clickFirstResultLead() {
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		return new ViewLeadPageEdit(driver);
	}

}
