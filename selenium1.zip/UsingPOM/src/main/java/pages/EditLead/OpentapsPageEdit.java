package pages.EditLead;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class OpentapsPageEdit extends ProjectSpecificMethods{
	
	public OpentapsPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	public OpentapsPageEdit changeCompanyName(String compN) {
		WebElement companyname=driver.findElementById("updateLeadForm_companyName");
		companyname.clear();
		companyname.sendKeys(compN);
		return this;
	}
	
	public OpentapsPageEdit clickUpdateButton() {
		driver.findElementByName("submitButton").click();
		return this; 
		
	}
	
	

}
