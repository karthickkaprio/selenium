package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class VeriyLeadsPageEdit extends ProjectSpecificMethods {
	
	public VeriyLeadsPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	public VeriyLeadsPageEdit enterTheNameEdit(String fName) {
		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys(fName);
		return this;
	}

	
	public VeriyLeadsPageEdit clickOnFindLeadsButtonEdit() throws InterruptedException {
		 driver.findElementByXPath("//button[text()='Find Leads']").click();
		 Thread.sleep(2000);
		 return this;
	}
    
    public void checkTheResult() {
    	String id=driver.findElementByXPath("(//table[@class='x-grid3-row-table'])[1]//tr[1]/td[5]").getText();
    	System.out.println("the value after edited is:"+id);
    	if(id.contains("Hackathon")) {
    		System.out.println("successful");
    	}
    	else {
    		System.out.println("not successful");
    	}
    }
}
