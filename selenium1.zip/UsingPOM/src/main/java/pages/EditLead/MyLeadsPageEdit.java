package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class MyLeadsPageEdit extends ProjectSpecificMethods {
	
	public MyLeadsPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public FindLeadsPageEdit clickFindLeads() {
		driver.findElementByLinkText("Find Leads").click();
		return new FindLeadsPageEdit(driver);
		
	}

}
