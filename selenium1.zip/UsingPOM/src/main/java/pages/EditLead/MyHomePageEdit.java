package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class MyHomePageEdit extends ProjectSpecificMethods {
	
	public MyHomePageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	public MyLeadsPageEdit clickLeads() {
		driver.findElementByLinkText("Leads").click();
		return new MyLeadsPageEdit(driver);
	}

}
