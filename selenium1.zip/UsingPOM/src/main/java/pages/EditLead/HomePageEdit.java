package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class HomePageEdit extends ProjectSpecificMethods{
	
	public HomePageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MyHomePageEdit clickcrmsfa(){
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePageEdit(driver);
	}
	public LoginPageEdit clickLogout() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPageEdit(driver); 
	}

}
