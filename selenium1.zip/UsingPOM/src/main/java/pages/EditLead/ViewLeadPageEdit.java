package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class ViewLeadPageEdit extends ProjectSpecificMethods {
	
	public ViewLeadPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	public OpentapsPageEdit clickEdit() {
		driver.findElementByLinkText("Edit").click();
		return new OpentapsPageEdit(driver);
	}

}
