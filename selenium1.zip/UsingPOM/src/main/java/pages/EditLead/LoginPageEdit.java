package pages.EditLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class LoginPageEdit extends ProjectSpecificMethods{
	
	public LoginPageEdit(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LoginPageEdit enterUserNameE(String userN) {
		driver.findElementById("username").sendKeys(userN);
		return this;
		}
	public LoginPageEdit enterPasswordE(String passW) {
		driver.findElementById("password").sendKeys(passW);
		return this;
	}
	public HomePageEdit clickLoginE() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePageEdit(driver);
	}

}
