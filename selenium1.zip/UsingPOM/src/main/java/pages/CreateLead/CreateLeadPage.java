package pages.CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods {
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public CreateLeadPage companyName(String cName) {
		driver.findElementById("createLeadForm_companyName").sendKeys(cName);
		return this;
	}
	public CreateLeadPage firstName(String fName) {
		driver.findElementById("createLeadForm_firstName").sendKeys(fName);
		return this;
	}
	public CreateLeadPage lastName(String lName) {
		driver.findElementById("createLeadForm_lastName").sendKeys(lName);
		return this;
	}
	public CreateLeadPage phoneNumber(String phNo) {
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys(phNo);
		return this;
    }
	public  ViewLeadPage clickSubmit() {
		driver.findElementByXPath("//input[@name='submitButton']").click();
		return new ViewLeadPage(driver);
	}

}
