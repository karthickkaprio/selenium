package pages.CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	
	public HomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	public MyHomePage clickCrmsfa() {
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage(driver);
	}
	
	public LoginPage clickLogout() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage(driver);
	}

}
