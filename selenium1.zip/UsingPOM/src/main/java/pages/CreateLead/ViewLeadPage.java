package pages.CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods {
	
	public ViewLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public void verifyLeadFirstname() {
		String leadName=driver.findElementById("viewLead_firstName_sp").getText();
		if(leadName.equals("karthick")) {
			System.out.println("i confirm and lead created successful");
		}
		else{
			System.out.println("not successful");
		}
	//Assert.assertEquals(leadName, "karthick");
	
	}
	

}