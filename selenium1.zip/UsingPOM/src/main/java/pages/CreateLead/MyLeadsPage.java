package pages.CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	public MyLeadsPage(ChromeDriver driver){
		this.driver=driver;
	}
	
	public CreateLeadPage clickCreateLead() {
		driver.findElementByXPath("//a[text()='Create Lead']").click();
		return new CreateLeadPage(driver);
	}

}
