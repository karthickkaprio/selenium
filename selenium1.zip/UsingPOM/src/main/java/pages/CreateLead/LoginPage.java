package pages.CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

import base.Common.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage enterUsername(String uName) {
		driver.findElementById("username").sendKeys(uName);
		return this;
	}
	
	public LoginPage enterPassword(String pWord) {
		driver.findElementById("password").sendKeys(pWord);
		return this;
	}
	
	public HomePage clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage(driver);
	}

}
