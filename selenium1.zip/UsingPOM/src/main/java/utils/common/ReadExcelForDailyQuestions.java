package utils.common;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelForDailyQuestions {

	public static void main(String[] args) throws IOException {
	 XSSFWorkbook wb=new XSSFWorkbook("./datafromExcel/dailyquestions.xlsx");
     XSSFSheet sheet= wb.getSheet("sheet1");
     XSSFRow row=sheet.getRow(2);
     System.out.println(row.getCell(3).getStringCellValue());
     wb.close();
	 }

}
