package utils.common;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	
	
	
	public static String[][] readData(String ExcelFile) throws IOException {
	XSSFWorkbook book=new XSSFWorkbook("./datafromExcel/"+ExcelFile+".xlsx"); 
	XSSFSheet sheet=book.getSheet("sheet1");
	
	int rowcount=sheet.getLastRowNum();
	int cellcount=sheet.getRow(0).getLastCellNum();
	                   //dynamic rowsize,cellsize
	String[][] data =new String[rowcount][cellcount];//2D array with datatype as string
	
	for(int i=1;i<=rowcount;i++) {
	for(int j=0;j<cellcount;j++) {
    String cellval=sheet.getRow(i).getCell(j).getStringCellValue();
   // System.out.println(cellval);
	data[i-1][j]=cellval;
	//System.out.println();
	//System.out.println(data);
	}
}
	book.close();
	return data;
	}
}
