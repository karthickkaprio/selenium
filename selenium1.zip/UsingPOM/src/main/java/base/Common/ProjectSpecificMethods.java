package base.Common;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.common.ReadExcelData;

public class ProjectSpecificMethods {
	public ChromeDriver driver;
	public String ExcelFile;
	
	@DataProvider(name="fetchdata")
	public String[][] sendData() throws IOException{
	//ReadExcelData exe=new ReadExcelData(); //no need because ReadExcelData is static
		          
		          //className.methodName
	String[][] val=ReadExcelData.readData(ExcelFile);
	return val;
	}
	
	
	@BeforeMethod
	public void preCondition() {
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("http://leaftaps.com/opentaps/control/login");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}
	/*@AfterMethod
	public  void postCondition() {
      driver.close();
    }*/
		
	}


