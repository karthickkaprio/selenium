package week1.day2;

public class cycle {
	//here just calling the method Name
	public void cycleName() {
		String cycle="Hercules";
		System.out.println(cycle);
	}
	//here we are passing the value through arguments
	public void CycleName2(String CycleName) {
		System.out.println("The cycle name is"+CycleName);
	}
	//here returns the value by calling in main method and printing
	public String cycleName1() {
		String cycle="ranger";
		return cycle;
	}
	//here just calling the value in main method
	public void cyclePrice() {
		int price=4000;
		System.out.println(price);
		}
	//here returns the stored value for future use by calling in main and printing
	public int cyclePrice1() {
		int price=5000;
		return price;
	}
	//here just returning the value by calling and printing
	public int CyclePrice2() {
		return 8000;
	}
	//here just passing the value from main and printing 
	public void CyclePrice3(int Cycleprice) {
	System.out.println("The cycle price is"+Cycleprice);	
	}
	//here just calling the stored value
	public void cycleColour() {
		String colour="red";
		System.out.println(colour);
		}
	//here return the value by calling in main and printing
	public String cycleColour1() {
		String colour="blue";
		return colour;
	}
	public String CycleColour2(String CycleColour) {
	return CycleColour;
	}
    public static void main(String[] args) {
	cycle object=new cycle();
	object.cycleName();//calling
	object.cyclePrice();//calling
	object.cycleColour();//calling
	object.CycleName2("Hero");//passing value
	object.CyclePrice3(70000);//passing the value
	System.out.println(object.cycleName1());//returning and print
	System.out.println(object.cyclePrice1());//return and print
	System.out.println(object.cycleColour1());//return and print
	System.out.println(object.CyclePrice2());//return and print
	System.out.println(object.CycleColour2("orange"));
	
	}

}
