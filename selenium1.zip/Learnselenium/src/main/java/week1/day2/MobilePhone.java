package week1.day2;

import week1.day1.Mobile;

public class MobilePhone {

	public static void main(String[] args) {
		Mobile object=new Mobile();//need to import the required class object
		System.out.println(object.a);//only public is accessible outside the package but within the project
		//System.out.println(object.b);//private cannot accessible outside package
		//System.out.println(object.val);//default also cannot accessible outside package 

	}

}
