package week1.day2;

public class PrintingValues {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			System.out.println("karthick");
		}
        for(int i=1;i<=100;i++) {
        	System.out.println(i);
        }
	int a=20,b=25,c=11;
	if((a>b)&&(a>c)){
	System.out.println(a);	
	}
	else if((b>a)&&(b>c)) {
		System.out.println(b);
	}
	else if((c>a)&&(c>b)) {
		System.out.println(b);
	}
		for(int i=1;i<=100;i++) {
			if(i%2!=0) {
				System.out.println(i);
				//System.out.println(true);
			}
			
			}
		}
	
	}
	
	


