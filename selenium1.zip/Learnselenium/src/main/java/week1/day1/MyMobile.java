package week1.day1;

public class MyMobile {

	public static void main(String[] args) {
		Mobile object=new Mobile();
		System.out.println(object.a);
		System.out.println(object.val1);// default can be accessed within package 
		//System.out.println(object.b);//private cannot be accessed outside the class

	}

}
