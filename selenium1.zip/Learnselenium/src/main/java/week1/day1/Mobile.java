package week1.day1;

public class Mobile {

	
		byte num1=36;
		int num2=1234567891;
		long num3=8778946739000l;
        short num4=12345;
        float num5=578.00f;
        double num6=500000.1000;
        char val='a';
        boolean res1=true;
        boolean res2=false;
        public int a =10;
        private int b=20;
        String val1="karthick";
        public static void main(String[] args) {
        	Mobile object=new Mobile();
        	System.out.println(object.num1);
        	System.out.println(object.num2);
        	System.out.println(object.num3);
        	System.out.println(object.num4);
        	System.out.println(object.num5);
        	System.out.println(object.num6);
        	System.out.println(object.val);
        	System.out.println(object.res1);
        	System.out.println(object.res2);
        	System.out.println(object.a);//public can be accessed inside class
        	System.out.println(object.b);//private can be accessed inside class
        	System.out.println(object.val1);//default can be accessed inside class
	}

}
