package createInterface;

public interface Create {
	
	public  void karthick();

}
