package annotationswithinheritance;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestCase1 extends BaseClass {
	
	 @BeforeClass
	 public void testcase() {
		 System.out.println("GrandfatherName1=Madasamy, GrandMotherName1=Vallithai");
	 }
	 @Test(priority=2)
	  public void testCase1() {
		 System.out.println("Name=karthick");
	  }
	 @Test(priority=1)
	  public void testCase2() {
		 System.out.println("Name=Mahesh");
	  }

}
