package annotationswithinheritance;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	 @BeforeClass
	 public void  testcase() {
		 System.out.println("GrandfatherName=Madasamy, GrandMotherName=Vallithai");
	 }
	 @BeforeMethod
	  public void testCase() {
		 System.out.println("Mother name= Amutha, mother name=Kala");
	  }
 
}
