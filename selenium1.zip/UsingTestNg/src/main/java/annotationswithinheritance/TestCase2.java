package annotationswithinheritance;

import org.testng.annotations.Test;

public class TestCase2 extends BaseClass {
	 @Test(enabled=false)
	  public void testCase3() {
		 System.out.println("Name=Kumar");
	  }
	 @Test(priority=3,invocationCount=4)
	  public void testCase4() {
		 System.out.println("Name=Marriappan");
	  }

}
