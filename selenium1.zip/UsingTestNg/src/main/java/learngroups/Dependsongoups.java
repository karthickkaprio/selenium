package learngroups;

import org.testng.annotations.Test;

public class Dependsongoups {
	@Test(groups= {"regression"})
   public void testcase1() {
	   throw new RuntimeException();
	  // System.out.println("Regression");
   }
	@Test(groups= {"functional"})
	   public void testcase2() {
		   System.out.println("Functional");
	   }
	@Test(groups= {"smoke"})
	   public void testcase3() {
		   System.out.println("Smoke");
	   }
	@Test(groups= {"sanity"},dependsOnGroups= {"regression"})
	   public void testcase4() {
		   System.out.println("A");
	   }
}
