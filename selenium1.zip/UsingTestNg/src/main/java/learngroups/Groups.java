package learngroups;

import org.testng.annotations.Test;

public class Groups {
	@Test(groups= {"regression"})
	public void Testcase1() {
		System.out.println("first");
	}
	@Test(groups= {"functional"})
	public void Testcase2() {
		System.out.println("second");
	}
	@Test(groups= {"smoke"})
	public void Testcase3() {
		System.out.println("Third");
	}
	@Test(groups= {"regression","smoke"})
	public void Testcase4() {
		System.out.println("fourth");
	}
	@Test(groups= {"regression","functional"})
	public void Testcase5() {
		System.out.println("Fifth");
	}
}
