package iRetryAnalyzer;

import org.testng.annotations.Test;

public class Test1 {
	@Test(timeOut=500,retryAnalyzer=RetryFailed.class)
	public void CreateLead() throws InterruptedException {
    //System.out.println(Math.random());//it will generate the number between 0-1
    long randomnum=(long) (Math.random()*1000);
    System.out.println(randomnum);
    Thread.sleep(randomnum);
}
}
