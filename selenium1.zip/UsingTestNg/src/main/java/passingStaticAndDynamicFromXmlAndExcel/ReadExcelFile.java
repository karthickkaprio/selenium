package passingStaticAndDynamicFromXmlAndExcel;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {

	public String[][] readData(String fileName) throws IOException {
		XSSFWorkbook ws=new XSSFWorkbook("./Exceldata/"+fileName+".xlsx");
        XSSFSheet sheet	=ws.getSheet("sheet1");
         int rowcount=sheet.getLastRowNum();
         int cellcount=sheet.getRow(0).getLastCellNum();
         String[][] data =new String[rowcount][cellcount];
                      
        for(int i=1;i<=rowcount;i++) {
        	for(int j=0;j<cellcount;j++) {
        		String cellval=sheet.getRow(i).getCell(j).getStringCellValue();
        		
        //XSSFRow rowcount=sheet.getRow(i);
       // XSSFCell cellcount= rowcount.getCell(j);
       //String val= cellcount.getStringCellValue();
       //System.out.println(cellval);
       data[i-1][j]=cellval;
      // System.out.println(data);
        }
        	}
        ws.close();
       return data;
       
       }

	
	}
