package passingStaticAndDynamicFromXmlAndExcel;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	RemoteWebDriver driver;
	public String ExcelFileName;
    @Parameters({"username","password"})
	@BeforeMethod
	public void preCondition(String uName, String pWord) {
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("http://leaftaps.com/opentaps/");
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementById("username").sendKeys(uName);
	driver.findElementById("password").sendKeys(pWord);
	driver.findElementByClassName("decorativeSubmit").click();
	driver.findElementByLinkText("CRM/SFA").click();
	driver.findElementByLinkText("Leads").click();
	}
    @DataProvider(name="fetchData")
    public String[][] sendData() throws IOException{
    	ReadExcelFile red=new ReadExcelFile();
    	String[][] data=red.readData(ExcelFileName);
    	return data;
    }

	@AfterMethod
	public void postcondition() {
		driver.close();
	}
}
