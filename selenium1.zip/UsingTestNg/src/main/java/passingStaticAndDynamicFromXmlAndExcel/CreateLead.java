package passingStaticAndDynamicFromXmlAndExcel;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CreateLead extends Base{
	@BeforeTest
	public void setfileName() {
		ExcelFileName="CreateLead";
	}
   
	@Test(dataProvider="fetchData")
	public void runCreateLead(String comp,String fName,String lName) {
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys(comp);
		driver.findElementById("createLeadForm_firstName").sendKeys(fName);
		driver.findElementById("createLeadForm_lastName").sendKeys(lName);
		driver.findElementByXPath("(//input[@name='primaryPhoneNumber'])[4]").sendKeys("5454545454");
		driver.findElementByName("submitButton").click();
	
}
   
}






