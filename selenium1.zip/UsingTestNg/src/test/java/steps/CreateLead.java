package steps;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead {
	
	public ChromeDriver driver;
	@Given("Launch the Chrome Browser")
	public void launchTheChromeBrowser() {
	   WebDriverManager.chromedriver().setup();
	   driver=new ChromeDriver();
	}
    @Given("Load the urlC")
    public void loadTheUrl() {
    	driver.get("http://leaftaps.com/opentaps/control/login");
    }
    @Given("Enter the UsernameC as demosalesmanager")
    public void enterTheUserName() {
    	driver.findElementById("username").sendKeys("demosalesmanager");
    }
    @Given("Enter the PasswordC as crmsfa")
    public void enterThePassword() {
    	driver.findElementById("password").sendKeys("crmsfa");
    }
	@When("Click Login Button")
	public void clickLoginButton() {
	   driver.findElementByClassName("decorativeSubmit").click();	
	}

	@Then("Homepage Should be Displayed")
	public void homepageShouldBeDisplayed() {
		System.out.println(driver.findElementByTagName("h2").getText());
	}

	@When("Click CRMSFA Link")
	public void clickCRMSFALink() {
	    driver.findElementByLinkText("CRM/SFA").click();
	}

	@Then("MyHomePage Should Be Displayed")
	public void myhomepageShouldBeDisplayed() {
	    System.out.println(driver.getTitle());
	}
	@When("Click on Leads")
	public void clickOnLeads() {
		driver.findElementByXPath("(//div[@class='x-panel-header']/a)[2]").click();
	}

	@When("Click on CreateLeads")
	public void clickOnCreateLeads() {
	   driver.findElementByLinkText("Create Lead").click();
	}

	@Given("Enter the CompanyName")
	public void enterTheCompanyName() {
	   driver.findElementById("createLeadForm_companyName").sendKeys("AscentCircuits");
	}

	@Given("Enter the FirstName")
	public void enterTheFirstName() {
	   driver.findElementById("createLeadForm_firstName").sendKeys("Karthick"); 
	}

	@Given("Enter the LastName")
	public void enterTheLastName() {
	   driver.findElementById("createLeadForm_lastName").sendKeys("N"); 
	}

	@Given("Enter the PhoneNumber")
	public void enterThePhoneNumber() {
		 driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("5454545454");
	}

	@When("Click on CreateLead")
	public void clickOnCreateLead() {
	    driver.findElementByClassName("smallSubmit").click();
	}

	@When("Click on FindLeads")
	public void clickOnFindLeads() {
	   driver.findElementByLinkText("Find Leads").click();
	}
    @When("Enter the Name")
    public void enterTheName() {
       driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("karthick");
    }
	@When("Click on FindLeads Button")
	public void clickOnFindLeadsButton() {
	    driver.findElementByXPath("//button[text()='Find Leads']").click();
	}

	@When("Click on Leads in Table")
	public void clickOnLeadsInTable() {
		driver.findElementByXPath("//div[@class='x-grid3-hd-inner x-grid3-hd-partyId']").click();
	}

	@When("Click on Last Resulting Leads")
	public void clickOnLastResultingLeads() {
	 String LeadId=driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").getText();
	 System.out.println(LeadId);
	}

}
