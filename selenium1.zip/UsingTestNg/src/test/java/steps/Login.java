package steps;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {
	
    public ChromeDriver driver;
	@Given("Launch the Chrome browser")
	public void launchTheChromeBrowser() {
		WebDriverManager.chromedriver().setup();
	    driver=new ChromeDriver(); 
	}

	@Given("Load the url")
	public void loadTheUrl() {
	    driver.get("http://leaftaps.com/opentaps/control/login");  
	}

	@Given("Enter the username as (.*)")
	public void enterTheUsernameAsDemosalesmanager(String name) {
		driver.findElementById("username").sendKeys(name);
	}

	@Given("Enter the password as (.*)")
	public void enterThePasswordAsCrmsfa(String pass) {
	    driver.findElementById("password").sendKeys(pass); 
	}

	@When("Click the login")
	public void clickTheLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}

	@Then("Homepage should be displayed")
	public void homepageShouldBeDisplayed() {
		System.out.println(driver.findElementByTagName("h2").getText());
	}
	
	
	@Given("Enter the Username as (.*)")
	public void enterTheUsernameAsDemosalesmanager1(String name) {
		driver.findElementById("username").sendKeys(name);
	}

	@Given("Enter the Password as (.*)")
	public void enterThePasswordAsCrmsfa1(String pass) {
	    driver.findElementById("password").sendKeys(pass); 
	}

	@When("Click the Login")
	public void clickTheLogin1() {
		driver.findElementByClassName("decorativeSubmit").click();
	}

	@But("Error should be displayed")
    public void errorMessageShouldBeDisplayed() {
		System.out.println(driver.findElementByXPath("//div[@id='errorDiv']").getText());
    }
}
    
    
    
    
    
    
    
