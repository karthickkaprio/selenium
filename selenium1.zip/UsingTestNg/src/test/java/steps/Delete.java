package steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Delete extends BaseClass{
	public static String leadID;
	
	@Given("Enter the usernameD as Demosalesmanager")
	public void enterTheUsernameDAsDemosalesmanager() {
		driver.findElementById("username").sendKeys("Demosalesmanager");  
	}

	@Given("Enter thr passwordD as crmsfa")
	public void enterThrPasswordDAsCrmsfa() {
		driver.findElementById("password").sendKeys("crmsfa");
    	
	}

	@When("Click on LoginD")
	public void clickOnLoginD() {
		driver.findElementByClassName("decorativeSubmit").click();
	}

	@Then("HomePage Should be displayed")
	public void homepageShouldBeDisplayed() {
		System.out.println(driver.findElementByTagName("h2").getText());
	}

	@When("Click crmsfa link")
	public void clickCrmsfaLink() {
		driver.findElementByLinkText("CRM/SFA").click();
    	
	}

	@Then("Leads Page Should be displayed")
	public void leadsPageShouldBeDisplayed() {
		 System.out.println(driver.getTitle());
	}

	@When("Click on LeadsD")
	public void clickOnLeadsD() {
		driver.findElementByLinkText("Leads").click();
	}

	@When("Click on Find LeadsD")
	public void clickOnFindLeadsD() {
		driver.findElementByLinkText("Find Leads").click();
	}

	@Given("Enter the phoneNumberD")
	public void enterThePhoneNumberD() {
		driver.findElementByXPath("//span[text()='Phone']").click();
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys("5454545454");
	}

	@When("Click on Find Leads ButtonD")
	public void clickOnFindLeadsButtonD() throws InterruptedException {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
	}

	@When("Click on First Resulting LeadD")
	public void clickOnFirstResultingLeadD() {
	    leadID = driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").getText();
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		}

	@When("Click on Delete Button")
	public void clickOnDeleteButton() {
		driver.findElementByLinkText("Delete").click();
	}

	@When("Click on Find LeadsDe")
	public void clickOnFindLeadsDe(){
		driver.findElementByLinkText("Find Leads").click();
		
	}

	@Given("Enter the Lead ID")
	public void enterTheLeadID() {
		driver.findElementByXPath("//input[@name='id']").sendKeys(leadID);
	}

	@When("Click on Find Leads ButtonDe")
	public void clickOnFindLeadsButtonDe() throws InterruptedException {
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
	}

	@When("Get the Text and Check the Result and confirm")
	public void getTheTextAndCheckTheResultAndConfirm() {
		String text = driver.findElementByClassName("x-paging-info").getText();
		if (text.equals("No records to display")) {
			System.out.println("Text matched");
		} else {
			System.out.println("Text not matched");
		}
		driver.close();
	}
}
