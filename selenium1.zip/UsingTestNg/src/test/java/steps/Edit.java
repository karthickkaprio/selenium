package steps;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Edit extends BaseClass {
	
     
	@Given("Enter the UsernameE as demosalesmanager")
	public void enterTheUsernameEAsDemosalesmanager() {
		driver.findElementById("username").sendKeys("demosalesmanager");
	}

	@Given("Enter the PasswordE as crmsfa")
	public void enterThePasswordEAsCrmsfa() {
		driver.findElementById("password").sendKeys("crmsfa"); 
	}

	@When("Click Login ButtonE")
	public void clickLoginButtonE() {
		driver.findElementByClassName("decorativeSubmit").click();
	}

	@Then("Homepage Should be DisplayedE")
	public void homepageShouldBeDisplayedE() {
		System.out.println(driver.findElementByTagName("h2").getText());
	}

	@When("Click CRMSFA LinkE")
	public void clickCRMSFALinkE() {
		driver.findElementByLinkText("CRM/SFA").click();
	}

	@Then("MyHomePage Should Be DisplayedE")
	public void myhomepageShouldBeDisplayedE() {
		 System.out.println(driver.getTitle());
	}

	@When("Click on LeadsE")
	public void clickOnLeadsE() {
		driver.findElementByXPath("(//div[@class='x-panel-header']/a)[2]").click();
	}

	@When("Click on FindLeadsE")
	public void clickOnFindLeadsE() {
		 driver.findElementByLinkText("Find Leads").click();
	}

	@Given("Enter the NameE")
	public void enterTheNameE() {
		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("karthick");
	}

	@When("Click on FindLeads ButtonE")
	public void clickOnFindLeadsButtonE() throws InterruptedException {
		 driver.findElementByXPath("//button[text()='Find Leads']").click();
		 Thread.sleep(2000);
	}
	
	@When("Click 0n First Resulting Lead")
	public void clickOnFirstResultingLead() {
		WebElement table=driver.findElementByXPath("//table[@class='x-grid3-row-table']");
        List<WebElement> allrow=table.findElements(By.tagName("tr"));
        List<String> list=new ArrayList<String>();	    
        for(int i=0;i<=allrow.size();i++) {
	    List<WebElement> allcolumn=table.findElements(By.tagName("td"));
	     list.add(allcolumn.get(0).getText());
	    }
        for(String val:list) {
        	System.out.println(val);
        }
        String id=driver.findElementByXPath("(//table[@class='x-grid3-row-table'])[1]//tr[1]/td[5]").getText();
        System.out.println("The selected id is:"+id);
        driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
        }
	
	@When("Click on Edit")
	public void clickOnEdit() {
		driver.findElementByLinkText("Edit").click();
	}
	
	@When("Clear the oldvalue in Company And Enter the new value")
	public void clearTheOldvalueInCompanyAndEnterTheNewValue() {
		WebElement company=driver.findElementById("updateLeadForm_companyName");
		company.clear();
		company.sendKeys("Hackathon");
	}
    @When("Click on submit button")
    public void clickOnsubmitButton() {
    	driver.findElementByName("submitButton").click();
    }
    @When("Click on LeadsE1")
	public void clickOnLeadsE1() {
		driver.findElementByXPath("(//div[@class='x-panel-header']/a)[2]").click();
	}

	@When("Click on FindLeadsE1")
	public void clickOnFindLeadsE1() {
		 driver.findElementByLinkText("Find Leads").click();
		 
	}

	@Given("Enter the NameE1")
	public void enterTheNameE1() {
		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("karthick");
	}

	@When("Click on FindLeads ButtonE1")
	public void clickOnFindLeadsButtonE1() throws InterruptedException {
		 driver.findElementByXPath("//button[text()='Find Leads']").click();
		 Thread.sleep(2000);
	}
    @Then("Check the Result")
    public void checkTheResult() {
    	String id=driver.findElementByXPath("(//table[@class='x-grid3-row-table'])[1]//tr[1]/td[5]").getText();
    	System.out.println("the value after edited is:"+id);
    	if(id.contains("Hackathon")) {
    		System.out.println("successful");
    	}
    	else {
    		System.out.println("not successful");
    	}
    }
}
