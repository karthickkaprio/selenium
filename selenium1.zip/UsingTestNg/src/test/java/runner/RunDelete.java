package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features= {"src/test/java/features/Delete.feature"},
                 glue= {"steps"})//dryRun=true,monochrome=true,snippets=SnippetType.CAMELCASE)
public class RunDelete extends AbstractTestNGCucumberTests {
 
}
