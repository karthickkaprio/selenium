package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features= {"src/test/java/features/Edit.feature"},
                 glue= {"steps"})//,dryRun=true,monochrome=true,snippets=SnippetType.CAMELCASE)
public class RunEdit extends AbstractTestNGCucumberTests{

}
