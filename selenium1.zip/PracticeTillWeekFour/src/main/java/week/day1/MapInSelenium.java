package week.day1;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MapInSelenium {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://erail.in/");
		driver.findElementByXPath("//input[@id='chkSelectDateOnly']").click();
		WebElement frombox=driver.findElementById("txtStationFrom");
		frombox.clear();
		frombox.sendKeys("Mgr Chennai Ctr");
	
		WebElement tobox=driver.findElementById("txtStationTo");
		tobox.clear();
		tobox.sendKeys("Hyderabad Decan");
		
		
		
		//driver.findElementById("buttonFromTo").click();
		//WebDriverWait wait=new WebDriverWait(driver,timeoutInSeconds);
		//wait.until(ExpectedConditions.elementToBeClickable(By.id("buttonFromTo")));
		
		WebElement table=driver.findElementByXPath("//div[@id='divTrainsList']/table//tr");
		List <WebElement> allrow =table.findElements(By.tagName("tr"));
        System.out.println(allrow.size());
        
        for (WebElement eachrow: allrow) {
       List <WebElement> allcolumn= eachrow.findElements(By.tagName("td"));
       
       List<String> trainname=new ArrayList<>(); 
       trainname.add(allcolumn.get(1).getText());
       Collections.sort(trainname);
       System.out.println(trainname);
       
       
      // System.out.println(allcolumn.get(1).getText());
        
       }
			
		}
	}



