package com.MyServiceNow.Pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;

public class GroupsPage extends ProjectSpecificMethods {
 
	public IncidentMangePage assignmentGroup() throws InterruptedException {
    Set<String> assignwindows=driver.getWindowHandles();
	List<String> listwindow=new ArrayList<String>();
	listwindow.addAll(assignwindows);
	String childwindow=listwindow.get(1);
	driver.switchTo().window(childwindow);
	System.out.println("the child window is"+driver.getTitle());
	driver.findElementByXPath("(//input[@class='form-control'])[1]").sendKeys("software",Keys.ENTER);
	Thread.sleep(5000);
    WebElement table=driver.findElementByXPath("//table[@id='sys_user_group_table']");
	List<WebElement> allcolumndata=table.findElements(By.tagName("td"));
    for(int j=0;j<=allcolumndata.size()-1;j++) {
    String col=allcolumndata.get(j).getText();
    if(col.contains("Software")) {
    driver.findElementByXPath("//a[text()='Software']").click();
    break;
    }
    }
    driver.switchTo().window(parentwindow);
	System.out.println("the parent window after completing child activity is"+driver.getTitle());
	return new IncidentMangePage();
 }

   public IncidentMangePage toGroup() throws InterruptedException {
	Set<String> towindows =driver.getWindowHandles();
	List<String> listwindow1=new ArrayList<String>();
	listwindow1.addAll(towindows);
	String childwindow1=listwindow1.get(1);
	driver.switchTo().window(childwindow1);
	driver.findElementByXPath("(//input[@class='form-control'])[1]").sendKeys("itil",Keys.ENTER);
	Thread.sleep(5000);
	WebElement table1=driver.findElementByXPath("//table[@id='sys_user_table']");
	List<WebElement> columndata1=table1.findElements(By.tagName("td"));
		for(int j=0;j<=columndata1.size()-1;j++) {
		 String col=columndata1.get(j).getText();
		 if(col.contains("ITIL User")) {
         driver.findElementByXPath("//a[text()='ITIL User']").click();
         break;
         }
		}
    driver.switchTo().window(parentwindow);
    return new IncidentMangePage();
    
}
}

