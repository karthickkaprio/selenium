package com.MyServiceNow.Pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;

public class IncidentMangePage extends ProjectSpecificMethods {
		
	
	
	public IncidentMangePage enterFilter() throws InterruptedException {
	 WebElement filter=driver.findElementByXPath("//input[@id='filter']");
	 filter.sendKeys("incident",Keys.ENTER);
	 Thread.sleep(2000);
	 return this;
	}
	
	public IncidentMangePage clickIncidents() throws InterruptedException {
		driver.findElementByXPath("(//div[text()='Incidents'])[2]").click();
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage clickCreateNew() throws InterruptedException {
		driver.findElementByLinkText("Create New").click();
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage frame2() throws InterruptedException {
		WebElement frm2=driver.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(frm2);
		//Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage frame3() throws InterruptedException {
		WebDriverWait wait=new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@id='gsft_main']")));
		return this;
	}
	public IncidentMangePage readIncidentNumber() {
		WebElement num=driver.findElementByXPath("//input[@id='incident.number']");
		number=num.getText();
		System.out.println(number);
		return this;
	}
	
	public IncidentMangePage enterCaller() throws InterruptedException {
		driver.findElementByXPath("//input[@id='sys_display.incident.caller_id']").sendKeys("Abel Tuter");
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage entershortDescription() throws InterruptedException {
		driver.findElementByXPath("//input[@id='incident.short_description']").sendKeys("Issue with a web page");
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage enterDescription() {
		driver.findElementByXPath("//textarea[@id='incident.description']").sendKeys("hello");
		return this;
	}
	public IncidentMangePage clickSubmit() throws InterruptedException {
		driver.findElementById("sysverb_insert_bottom").click();
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage search() throws InterruptedException {
		driver.findElementByXPath("(//input[@class='form-control'])[1]").sendKeys(number,Keys.ENTER);
		Thread.sleep(2000);
		return this;
	}
	
	public IncidentMangePage searchExistingIncident() throws InterruptedException {
		WebElement dropdown=driver.findElementByXPath("//select[@class='form-control default-focus-outline']");
		Select drop=new Select(dropdown);
		drop.selectByIndex(1);
		driver.findElementByXPath("(//input[@class='form-control'])[1]").sendKeys("INC0010014",Keys.ENTER);
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage clickExistingIncident() throws InterruptedException {
		WebElement table=driver.findElementByXPath("(//table[@id='incident_table']//tr)[3]");
		//List<WebElement> row=table.findElements(By.tagName("tr"));
		//table.findElements(By.tagName("tr")).get(1);
		//for(int i=0;i<=row.size();i++) {
		//	row.get(3);	
		//List<WebElement> column=table.findElements(By.tagName("td"));
		table.findElements(By.tagName("td")).get(2).click();
		//column.get(2).click();
		//}
		Thread.sleep(2000);
		return this;
	}
	
	public IncidentMangePage updateUrgency() throws InterruptedException {
		WebElement dropdown2=driver.findElementByXPath("//select[@id='incident.urgency']");
		Select urgency=new Select(dropdown2);
	    urgency.getOptions().get(0).getText();
		urgency.selectByIndex(0);
		Thread.sleep(2000);
		return this;
	}
	
	public IncidentMangePage updateState() throws InterruptedException {
		WebElement dropdown3=driver.findElementByXPath("//select[@id='incident.state']");
		Select state=new Select(dropdown3);
		stateval=state.getOptions().get(1).getText();
		state.selectByIndex(1);
		Thread.sleep(2000);
		return this;
	}
	public IncidentMangePage updateStateforResolve() throws InterruptedException {
		WebElement dropdown3=driver.findElementByXPath("//select[@id='incident.state']");
		Select state=new Select(dropdown3);
		stateval=state.getOptions().get(1).getText();
		state.selectByIndex(1);
		Thread.sleep(2000);
		return this;
	}
	public GroupsPage assignGroup() throws InterruptedException {
		parentwindow=driver.getWindowHandle();
	    System.out.println("the parent window is"+driver.getTitle());
		driver.findElementByXPath("//button[@id='lookup.incident.assignment_group']/span").click();
		Thread.sleep(2000);
	    return new GroupsPage();
		}
     public GroupsPage to() throws InterruptedException {
		 parentwindow=driver.getWindowHandle();
	    System.out.println("the parent window is"+driver.getTitle());
	    driver.findElementByXPath("(//span[@class='input-group-btn']/button)[5]").click();
		Thread.sleep(2000);
	    return new GroupsPage();
		}
	public IncidentMangePage mousehover() {
		WebElement hover=driver.findElementById("incident.form_scroll");
		Actions builder=new Actions(driver);
		builder.dragAndDrop(hover, null).perform();
		return this;
		
		
	}
	public IncidentMangePage updateWorknote() {
		driver.findElementByXPath("//textarea[@id='activity-stream-textarea']").sendKeys("Done with Assigning group");
		return this;
	}
	
	public IncidentMangePage verifyIncident() {
		WebElement table=driver.findElementByXPath("//table[@id='incident_table']");
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		List<String> value=new ArrayList<String>();
		for(int i=0;i<=rows.size();i++) {
		List<WebElement> columndata	=table.findElements(By.tagName("td"));
		  String val=columndata.get(2).getText();
		  value.add(val);
		}
		if(value.contains(number)) {
			   System.out.println("incident created successfully");
			   }
		   else {
			   System.out.println("not created successfully");
		   }
		return this;
		}
	public IncidentMangePage verifyPriority() {
		WebElement dropdown4=driver.findElementByXPath("//select[@id='incident.priority']");
		Select priority=new Select(dropdown4);
		String val=priority.getOptions().get(3).getText();
		//System.out.println(val);
		if(val.contains("3 - Moderate")) {
			System.out.println("priority value is"+" "+val+" "+"Matched");
		}
		else {
			System.out.println("check the priority is not correct");
		}
		if(stateval.equalsIgnoreCase("in progress")) {
			System.out.println("State value is"+" "+stateval+" "+"Matched");
		}
		else {
			System.out.println("check the state is not correct");
		}
		return this;
	}
	
	public IncidentMangePage clickUpdate() throws InterruptedException {
		driver.findElementByXPath("//button[@id='sysverb_update']").click();
		Thread.sleep(5000);
		return this;
	}
	public IncidentMangePage verifyAssigningGroupAndTo() {
		WebElement check=driver.findElementByXPath("//table[@id='incident_table']");
		List<WebElement> column=check.findElements(By.tagName("td"));
		for(int i=1;i<=11;i++) {
		    String val=driver.findElementByXPath("(//td[@class='vt'])["+i+"]").getText();
		    if(val.contains("Software")) {
		    	System.out.println("yes assigned group has="+val);
		    }
		    if(val.contains("ITIL User")) {
		    	System.out.println("yes assigned to has="+val);
		    }
		}
		    return this;
		    }
		
	}
		
	

   

