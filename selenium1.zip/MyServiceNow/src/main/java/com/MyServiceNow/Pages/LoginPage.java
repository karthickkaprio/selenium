package com.MyServiceNow.Pages;

import org.openqa.selenium.WebElement;
import com.MyServiceNow.BaseChild.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage frm() {
		WebElement fra1=driver.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(fra1);
		return this;
	}
		public LoginPage enterUserName() {
		WebElement box1=driver.findElementByXPath("//input[@id='user_name']");
		box1.clear();
		box1.sendKeys("admin");
		return this;
		}
		public LoginPage enterPassword() {
		WebElement box2=driver.findElementByXPath("//input[@id='user_password']");
		box2.clear();
		box2.sendKeys("KARthick9518");
		return this;
	}
		public IncidentMangePage clickLogin() {
	        driver.findElementById("sysverb_login").click();
			return new IncidentMangePage();
		}
		

}
