package com.MyServiceNow.Base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.MyServiceNow.aDesign.Browser;
import com.MyServiceNow.aDesign.Element;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ServiceBase implements Browser,Element{
	
	public RemoteWebDriver driver;
	
	
	
	public RemoteWebDriver launchBrowser(String brow,String url) {
		
		   if(brow.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			 driver=new ChromeDriver();
	         }
	      else if(brow.equalsIgnoreCase("firefox")) {
		    WebDriverManager.firefoxdriver().setup();
		    driver= new FirefoxDriver();
	          }
		    else if(brow.equalsIgnoreCase("ie")) {
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		driver.navigate().to(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
}
}
