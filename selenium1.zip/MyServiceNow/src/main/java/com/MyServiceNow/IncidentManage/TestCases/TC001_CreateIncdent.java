package com.MyServiceNow.IncidentManage.TestCases;

import org.testng.annotations.Test;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;
import com.MyServiceNow.Pages.LoginPage;

public class TC001_CreateIncdent extends ProjectSpecificMethods {
	@Test
	public void incident() throws InterruptedException {
	LoginPage lp=new LoginPage();
	    
		 lp.frm()
		.enterUserName()
		.enterPassword()
		.clickLogin()
		.enterFilter()
		.clickCreateNew()
		.frame2()
		.readIncidentNumber()
		.enterCaller()
		.entershortDescription()
		.clickSubmit()
		.search()
		.verifyIncident();
		
	}

}
