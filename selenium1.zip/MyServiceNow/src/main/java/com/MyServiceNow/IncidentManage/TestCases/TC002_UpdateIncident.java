package com.MyServiceNow.IncidentManage.TestCases;

import org.testng.annotations.Test;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;
import com.MyServiceNow.Pages.LoginPage;

public class TC002_UpdateIncident  extends ProjectSpecificMethods{
  @Test
  public void update() throws InterruptedException {
	  LoginPage lp=new LoginPage();
	  lp.frm()
	  .enterUserName()
	  .enterPassword()
	  .clickLogin()
	  .enterFilter()
	  .clickIncidents()
	  .frame2()
	  .searchExistingIncident()
	  .clickExistingIncident()
	  .updateState()
	  .updateUrgency()
	  .verifyPriority()
	  .clickUpdate();
	  
	  
	  
	  
  }

}
