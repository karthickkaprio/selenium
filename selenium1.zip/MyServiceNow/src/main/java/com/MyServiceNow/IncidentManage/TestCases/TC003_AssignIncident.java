package com.MyServiceNow.IncidentManage.TestCases;

import org.testng.annotations.Test;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;
import com.MyServiceNow.Pages.LoginPage;

public class TC003_AssignIncident extends ProjectSpecificMethods{
	@Test
	public void assign() throws InterruptedException {
		LoginPage lp=new LoginPage();
		lp.frm()
		.enterUserName()
	    .enterPassword()
		.clickLogin()
		.enterFilter()
		.clickIncidents()
	    .frame2()
	    .searchExistingIncident()
	    .clickExistingIncident()
	    .updateState()
	    .updateUrgency()
	    .verifyPriority()
	    .assignGroup()
	    .assignmentGroup()
	    .frame2()
	    .to()
	    .toGroup()
	    .frame2()
	    .updateWorknote()
	    .clickUpdate()
	    .verifyAssigningGroupAndTo();
		
	   
	    
	   
	    
		
	}

}
