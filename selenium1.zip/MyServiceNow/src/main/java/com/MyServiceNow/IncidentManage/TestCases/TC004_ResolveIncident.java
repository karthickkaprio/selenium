package com.MyServiceNow.IncidentManage.TestCases;

import org.testng.annotations.Test;

import com.MyServiceNow.BaseChild.ProjectSpecificMethods;
import com.MyServiceNow.Pages.LoginPage;

public class TC004_ResolveIncident extends ProjectSpecificMethods {
	@Test
	public void resolve() throws InterruptedException {
		LoginPage lp=new LoginPage();
		lp.frm()
	      .enterUserName()
	      .enterPassword()
	      .clickLogin()
	      .enterFilter()
	      .clickIncidents()
	      .frame2()
	      .searchExistingIncident()
	      .clickExistingIncident();
	    //itha enna nu paru  //.updateState()
	}
	
}
