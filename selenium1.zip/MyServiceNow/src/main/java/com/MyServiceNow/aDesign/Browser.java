package com.MyServiceNow.aDesign;

public interface Browser {

}
