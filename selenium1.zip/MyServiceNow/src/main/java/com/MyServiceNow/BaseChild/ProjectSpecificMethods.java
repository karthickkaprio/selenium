package com.MyServiceNow.BaseChild;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecificMethods {
	public static ChromeDriver driver;
	public static String parentwindow;
	public String number,stateval;

	
@BeforeMethod

    public RemoteWebDriver lauchbrowser1() {
	WebDriverManager.chromedriver().setup();
	 driver=new ChromeDriver();
	 driver.get("https://dev77389.service-now.com/navpage.do");
	 driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
	 
}
	/*public RemoteWebDriver launchBrowser(String brow, String url) {
		
		   if(brow.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			 driver=new ChromeDriver();
	         }
	      else if(brow.equalsIgnoreCase("firefox")) {
		    WebDriverManager.firefoxdriver().setup();
		    driver= new FirefoxDriver();
	          }
		    else if(brow.equalsIgnoreCase("ie")) {
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		driver.navigate().to(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
}*/

/*@AfterMethod
public void afterMethod() {
	driver.close();
}*/
}

