package week2.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Launchbrowser {

	public static void main(String[] args) {

	WebDriverManager.firefoxdriver().setup();	
	FirefoxDriver driver=new FirefoxDriver();
	driver.get("http://leaftaps.com/opentaps/");
    WebElement eleusername=driver.findElementById("username");
    eleusername.sendKeys("Demosalesmanager");
    WebElement elepassword=driver.findElementById("password");
    elepassword.sendKeys("crmsfa");
    driver.findElementByClassName("decorativeSubmit").click();
    driver.findElementByLinkText("CRM/SFA").click();
    driver.findElementByLinkText("Leads").click();
    driver.findElementByLinkText("Create Lead").click();
    WebElement companyname=driver.findElementById("createLeadForm_companyName");
    companyname.click();
    companyname.sendKeys("selenium");
    WebElement firstname=driver.findElementById("createLeadForm_firstName");
    firstname.click();
    firstname.sendKeys("Karthick");
    WebElement lastname=driver.findElementById("createLeadForm_lastName");
    lastname.click();
    lastname.sendKeys("N");
    //driver.findElementByName("submitButton").click();
   // WebElement text=driver.findElementById("viewLead_companyName_sp");
   // System.out.println(text.getText());
    WebElement dropdown=driver.findElementById("createLeadForm_dataSourceId");
    dropdown.sendKeys("partner");
    //Select obj=new Select(dropdown);
    WebElement dropdown2=driver.findElementById("createLeadForm_marketingCampaignId");
    dropdown2.click();
    Select obj1=new Select(dropdown2);
    obj1.selectByVisibleText("Automobile");
    WebElement dropdown3=driver.findElementById("createLeadForm_industryEnumId");
    dropdown3.click();
    Select obj2=new Select(dropdown3);
    obj2.selectByIndex(9);
    WebElement dropdown4=driver.findElementById("createLeadForm_ownershipEnumId");
    dropdown4.click();
    Select obj3=new Select(dropdown4);
    obj3.selectByValue("OWN_CCORP");
  driver.findElementByName("submitButton").click();
  WebElement text=driver.findElementById("viewLead_companyName_sp");
  System.out.println(text.getText());
    
    
	}

}
