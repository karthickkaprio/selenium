package week2.day1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Usingxpath {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("http://leaftaps.com/opentaps");
		WebElement username=driver.findElementByXPath("//input[@id='username']");
		username.click();
		username.sendKeys("Demosalesmanager");
		
		WebElement password=driver.findElementByXPath("//input[@id='password']");
		password.click();
		password.sendKeys("crmsfa");
		driver.findElementByXPath("//input[@class='decorativeSubmit']").click();
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		driver.findElementByXPath("//a[text()='Create Lead']").click();
		WebElement companyname=driver.findElementByXPath("//input[@id='createLeadForm_companyName']");
		companyname.click();
		companyname.sendKeys("selenium");
		WebElement firstname=driver.findElementByXPath("//input[@id='createLeadForm_firstName']");
		firstname.click();
		firstname.sendKeys("Karthick");
		WebElement lastname=driver.findElementByXPath("//input[@id='createLeadForm_lastName']");
		lastname.click();
		lastname.sendKeys("N");
		WebElement dropdownsource=driver.findElementByXPath("//select[@id='createLeadForm_dataSourceId']");
		dropdownsource.click();
        Select obj=new Select(dropdownsource);
        obj.selectByVisibleText("Employee");
		//dropdownsource.click();
        WebElement dropdownmark=driver.findElementByXPath("//select[@name='marketingCampaignId']");
		dropdownmark.click();
        Select obj1=new Select(dropdownmark);
        obj1.selectByVisibleText("Automobile");
        WebElement dropdownind=driver.findElementByXPath("//select[@name='industryEnumId']");
		dropdownind.click();
        Select obj2=new Select(dropdownind);
        obj2.selectByIndex(9);
        WebElement dropdownown=driver.findElementByXPath("//select[@name='ownershipEnumId']");
		dropdownown.click();
        Select obj3=new Select(dropdownown);
        obj3.selectByValue("OWN_CCORP");
        driver.findElementByXPath("//input[@class='smallSubmit']").click();
        WebElement text=driver.findElementById("viewLead_companyName_sp");
        System.out.println(text.getText());
        //System.out.println(driver.findElementByXPath("//span[@text()='selenium (10840)']").getText());
	}

}
