package week4.day1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ClassRoom2 {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
        FirefoxDriver driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("http://erail.in");
        driver.findElementByXPath("//input[@id='chkSelectDateOnly']").click();
        driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
        driver.findElementById("txtStationTo").sendKeys("SBC",Keys.TAB);
        WebElement table=driver.findElementByXPath("//table[@id='myTable']//tr/th[2]");
        List<WebElement> allrows=table.findElements(By.tagName("tr"));
        System.out.println(allrows.size());
        for(WebElement eachrow:allrows) {
        	List<WebElement> allcolumns=eachrow.findElements(By.tagName("th"));
        	System.out.println(allcolumns.get(1).getText());
        	
        }

	}

	
}
