package week4.day1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ClassRoom1 {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();	
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		WebElement eleframe=driver.findElementById("iframeResult");
		driver.switchTo().frame(eleframe);
		driver.findElementByXPath("//button[text()='Try it']").click();
		Alert prompt=driver.switchTo().alert();
		System.out.println(prompt.getText());
		prompt.sendKeys("karthick");
		prompt.accept();
		//WebElement eleframe1=driver.findElementById("iframeResult");
		//driver.switchTo().frame(eleframe1);
		String val=eleframe.getText();
		if(val.contains("karthick")) {
			System.out.println("i confirm");
		}
		
		

	}

}
