package week4.day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ClassRoom3 {

	public static void main(String[] args) {
		WebDriverManager.firefoxdriver().setup();
        FirefoxDriver driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://jqueryui.com/draggable/");
        WebElement eledraggable=driver.findElementByClassName("demo-frame");
        driver.switchTo().frame(eledraggable);
        Actions builder=new Actions(driver);
        WebElement drag=driver.findElementById("draggable");
        builder.dragAndDropBy(drag, 100, 100).perform();

	}

}
