package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethods {
	@BeforeTest
	public void setDetails() {
		ExcelFile = "forpom";
		testName = "VerifyLogin";
		testDescription = "Verify Login for valid data";
		testAuthor = "Karthick";
		testCategory = "Smoke";

	}
	
	@Test(dataProvider="fetchData")
	public void verifyLogin(String username,String password) throws InterruptedException, IOException {
						
		new LoginPage(driver)
		.enterusername(username)
		.enterpassword(password)
		.clicklogin()
		.verifyPageTitle();
	}
}
