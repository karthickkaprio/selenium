package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setDetails() {
		ExcelFile="forpom";
		testName="LoginAndLogout";
		testDescription="Login and Logout with Valid Data";
		testAuthor="karthick";
		testCategory="smoke";
		}
	
	@Test(dataProvider="fetchdata")
	public void LoginLogout(String uName,String pWord) throws IOException {

	LoginPage lp=new LoginPage(driver);
	lp.enterusername(uName)
	.enterpassword(pWord)
	.clicklogin();
	
		

	}

}
