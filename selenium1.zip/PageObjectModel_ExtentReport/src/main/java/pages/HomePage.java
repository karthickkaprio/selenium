package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	public HomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage clicklogout() throws IOException {
	try {
		driver.findElementByClassName("decorativeSubmit").click();
		reportStep("logout clicked successfully","pass");
	}catch(Exception e) {
		reportStep("logout not clicked successfully","fail");
	}
	
		return new LoginPage(driver);
	}
	public HomePage verifyPageTitle() throws IOException {

		String actualTitle="";
		try {
			actualTitle = driver.getTitle();
			if (actualTitle.equals(actualTitle)) {
				reportStep("Title is matching", "pass");
			}
			else {
				reportStep("Title is not matching", "fail");
			}
			
		} catch (Exception e) {
			reportStep("Title is not matching", "fail");
		}
		return this;

	}

}
