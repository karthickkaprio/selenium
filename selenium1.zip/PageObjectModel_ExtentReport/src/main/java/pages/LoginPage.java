package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
  public LoginPage enterusername(String uName) throws IOException {
	  try {
		  driver.findElementById("username").sendKeys(uName);
		  reportStep(uName +"username entered successfully","pass");
	  }catch(Exception e) {
		  reportStep(uName +"username not entered successfully","fail");
	  }
	  return this;
  }
 
  public LoginPage enterpassword(String pWord) throws IOException {
	  try {
		  driver.findElementById("password").sendKeys(pWord);
		  reportStep(pWord +"password entered successfuly","pass");
		  }catch(Exception e) {
			  reportStep(pWord +"password not entered successfully","fail");
		  }
	   return this;
  }
  
  public HomePage clicklogin() throws IOException {
	  try {
		  driver.findElementByClassName("decorativeSubmit").click();
		  reportStep("login clicked successfully","pass");
		  }catch(Exception e) {
			  reportStep("login not clicked successfully", "fail");
		  }
	  return new HomePage(driver);
  }
}
