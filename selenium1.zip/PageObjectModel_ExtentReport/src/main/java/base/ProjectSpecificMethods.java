package base;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.graphbuilder.struc.LinkedList.Node;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadingExcelValues;

public class ProjectSpecificMethods {
	public  ChromeDriver driver;
	public String ExcelFile;
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	
	public String testName,testDescription,testAuthor,testCategory;
	
	
	@BeforeSuite
	public void startReport() {
        reporter=new ExtentHtmlReporter("./ExtentReport/result.html");
		reporter.setAppendExisting(true);
		extent=new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	
	@BeforeClass
     public void testCaseDetails() {
	    test=extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	public long takesnaps() throws IOException {
		
		long number=(long)Math.floor(Math.random()*9000000L);
		File source=driver.getScreenshotAs(OutputType.FILE);
		File dest=new File("./snaps/"+number+".png");
		FileUtils.copyFile(source, dest);
		return number;
	}
	public void reportStep(String msg,String status) throws IOException {
		if(status.equals("pass")) {
			node.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takesnaps()+".png").build());
		}
		else {
			long takesnaps=takesnaps();
			node.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takesnaps+".png").build());
			throw new RuntimeException();
		}
	}
	
	
	@BeforeMethod
	public void preCondition() {
		node=test.createNode(testName, testDescription);
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	@AfterMethod
	public void postCondition() {
		driver.close();
	}
	
	@DataProvider(name="fetchdata")
	public String[][] sendData() throws IOException {
		String[][] val =ReadingExcelValues.readData(ExcelFile);
	    return val;
	}
	@AfterSuite
    public void endReport() {
		extent.flush();
	}

}
