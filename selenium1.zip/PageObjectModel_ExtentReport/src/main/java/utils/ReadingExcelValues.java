package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadingExcelValues {

	public static String[][] readData(String ExcelFile) throws IOException {
		XSSFWorkbook wb=new XSSFWorkbook("./excelvalues/"+ExcelFile+".xlsx");
		XSSFSheet sheet=wb.getSheet("Sheet1");
		
		int rowcount =sheet.getLastRowNum();
		int cellcount =sheet.getRow(0).getLastCellNum();
		
		String[][] data=new String[rowcount][cellcount];
		
		for(int i=1;i<=rowcount;i++) {
			 for(int j=0;j<cellcount;j++) {
				String cellval=sheet.getRow(i).getCell(j).getStringCellValue();
				System.out.println(cellval);
				data[i-1][j]=cellval;
		}
	}
           wb.close();
            return data;

}
}
