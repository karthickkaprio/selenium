package atlassian.first.Base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import utils.Reports;

public class Orgin extends Reports {
	
	

	public RemoteWebDriver browserSelect(String brow, String url) {
	 if(brow.equalsIgnoreCase("chrome")) {
		 System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
			driver=new ChromeDriver();
	 }
	 else if(brow.equalsIgnoreCase("firefox")) {
		 System.setProperty("webdriver.gecko.driver", "./driver/geckodriver_32 bit.exe");
			driver=new FirefoxDriver();
	 }
	
	    driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
	 }
	 public void clearAndType(WebElement eleUser) throws IOException {
		try{
			eleUser.clear();
			eleUser.sendKeys("karthickkala93@gmail.com");
			reportStep("The Element username is getting typed","pass");
		}
		catch(StaleElementReferenceException e){
			reportStep("The Element username is not getting Typed","fail");
			throw new RuntimeException();
		}
		    
	 }
	 public void clearAndType1(WebElement elePass) throws IOException {
		try {
			elePass.clear();
			elePass.sendKeys("KARthick9518");
			reportStep("The Element password is getting Typed","pass");
		}
		catch(StaleElementReferenceException e) {
			reportStep("The Element password is not gettting Typed","fail");
			throw new RuntimeException();
		}
		 
		 
	 }
	 public void click(WebElement button) throws IOException {
		try {
			button.click();
			reportStep("The Button is clicked","pass");
		}catch(StaleElementReferenceException e) {
			reportStep("The button not clicked","fail");
			throw new RuntimeException();
		}
		
	 }
     public void close() {
	  driver.close();
     }
}
