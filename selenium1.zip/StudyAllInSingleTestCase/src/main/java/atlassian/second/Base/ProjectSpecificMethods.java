package atlassian.second.Base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import atlassian.first.Base.Orgin;

public class ProjectSpecificMethods extends Orgin {
	
	
	
	
	@BeforeMethod
	public void beforeMethods() {
	driver=browserSelect("firefox", "https://id.atlassian.com/login");
	node=test.createNode(TestCaseName, TestDescription);
		
	}
   
	
	@AfterMethod
    public void afterMethod() {
    	close();
    }
}
