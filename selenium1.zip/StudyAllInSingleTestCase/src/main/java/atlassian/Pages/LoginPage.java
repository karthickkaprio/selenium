package atlassian.Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import atlassian.second.Base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(RemoteWebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
//hari.radhakrishnan@testleaf.com
	
	@FindBy(how=How.ID,using="username")
	private WebElement eleUser;
	
	@FindBy(how=How.ID,using="login-submit")
	private WebElement button;
	
	@FindBy(how=How.XPATH,using="//input[@id='password']")
	private WebElement elePass;
	
	
	
	public LoginPage enterUserName() throws IOException {
		clearAndType(eleUser);
		return this;
	}
	public LoginPage clickNext() throws InterruptedException, IOException {
		click(button);
		Thread.sleep(2000);
		return this;
    }
	public LoginPage enterPassword() throws IOException {
		clearAndType1(elePass);
		return this;
	}
	public LoginPage clickLogin() throws IOException {
		click(button);
		return this;
	}
}
