package atlassianTestcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import atlassian.Pages.LoginPage;
import atlassian.second.Base.ProjectSpecificMethods;

public class TC_001_LoginPage extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		TestCaseName="LoginAndLogout";
		TestDescription="LoginTestCase";
		Author="Karthick";
		Category="smoke";
	}
    @Test
	public void Login() throws InterruptedException, IOException {
		new LoginPage(driver)
		.enterUserName()
		.clickNext()
		.enterPassword()
		.clickLogin();
	}
	
	
}
