package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Reports {
	public RemoteWebDriver driver;
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	public String TestCaseName,TestDescription,Author,Category; 
	
	
	@BeforeSuite
	public void startReport() {
		 reporter=new ExtentHtmlReporter("./Extentreport/result.html");
		 reporter.setAppendExisting(true);
		 extent=new ExtentReports();
		 extent.attachReporter(reporter);
	}
	
	@BeforeClass
    public void report() {
    	 test=extent.createTest(TestCaseName, TestDescription);
    	 test.assignAuthor(Author);
    	 test.assignCategory(Category);
    }
	public long takesnap() throws IOException {
		 long number=(long)(Math.random()*90000000L);
		 File src=driver.getScreenshotAs(OutputType.FILE);
		 File des=new File("./snaps/"+number+".png");
		 FileUtils.copyFile(src, des);
		 return number;
		}
		public void reportStep(String des,String Status) throws IOException {
			if(Status.equalsIgnoreCase("pass")) {
				node.pass(des,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takesnap()+".png").build());
			}
			else {
				long takesnap=takesnap();
				node.fail(des, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+takesnap+".png").build());
			}
	}
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
}
