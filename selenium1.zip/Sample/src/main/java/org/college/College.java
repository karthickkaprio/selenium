package org.college;

public class College {
	public void collegeName() {
		System.out.println("National College of Engineering");
	}
	public void collegeCode() {
		System.out.println("1111");
	}
	public void collegeRank() {
		System.out.println("37");
	}

}
