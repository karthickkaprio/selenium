package org.student;

import org.department.Department;

public class Student extends Department {
	public void studentName() {
		System.out.println("karthick");
	}
	public void studentDept() {
		System.out.println("Electronics and communication");
	}
	public void StudentId() {
		System.out.println("11EC35");
	}
public static void main(String[] args) {
	Student obj=new Student();
	obj.collegeName();
	obj.collegeCode();
	obj.collegeRank();
	obj.deptName();
	obj.studentName();
	obj.studentDept();
	obj.StudentId();
	
}
}
