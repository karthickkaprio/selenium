package learn.basics;
import java.io.IOException;

public class SecondProgram {
private static boolean error=true;
private static int errorcount=0;

public static int add(int a,int b) {
	int result=a+b;
	return result;
}
public boolean geterror() {
	return error;
}
public int geterrorcount() {
	return ++errorcount;
}
public void reseterror(boolean error) {
	System.out.println(error);
}

public int average(int d,int g,int h) {
int average=(d+g+h)/3;
return average;
}
public static int small(int i,int j,int z) {
	return Math.min(Math.min(i, j),z);
}


public void middle(String value) {
	String val=value.concat("kaprio");
	System.out.println(val);
}
public static void main(String[] args) throws IOException {
System.out.println(SecondProgram.small(25, 45, 68));	
int result=add(10,30);
System.out.println(result);
SecondProgram object=new SecondProgram();
System.out.println(object.geterror());
System.out.println(object.geterrorcount());
object.reseterror(false);
System.out.println(object.average(25, 56, 57));
object.middle("Karthick");


/*char ch,answer='A';
System.out.println("iam having the values from A-Z");
System.out.println("can you guess");
ch =(char)System.in.read();
if(ch==answer) {
	System.out.println("you are Right");
}*/
int number=13;

for(int i=2;i<=number;i++) {
	//System.out.println("prime number");
	if(number%i==0) {
		System.out.println("the number is not prime");
		break;
	}
	i++;
	if(i==number) {
		System.out.println("the number is  prime");
	}
}







}

}
