package learn.basics;

public class ThirdProgram {
	
public void interest(double p,double t,double r) {
	double SI=(p*t/12*r)/100;
	System.out.println("Amount="+p+"\n"+"Time="+t+"\n"+"Rate="+r+"\n"+"SI="+SI);
	}
public double BodyMass(double KG,double HT) {
	double BMI=(KG/(HT*HT))*10000;
	return BMI;
	
	}
public static void main(String[] args) {
ThirdProgram object=new ThirdProgram();
object.interest(15000, 365, 10.25);
double BMI=object.BodyMass(78, 167);
System.out.println("The Good BMI should BE"+"\n"+"Morethan 18 and lessthan 24");
System.out.println("your BMI is="+BMI);

if((BMI>18)&&(BMI<24)) {
	System.out.println("you are normal weight");
	}
else {
	System.out.println("you are over weight");
}
/*double kg=67,ht=169.0,bmi;
 bmi=(kg/(ht*ht))*10000;
 System.out.println("your bmi is="+bmi);*/
}
}
