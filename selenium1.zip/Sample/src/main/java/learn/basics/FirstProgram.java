package learn.basics;
import javax.swing.*;
public class FirstProgram {
public static void main(String[] args) {
	int a,b;
	a=10;
	b=2;
	if (b!=0 & a%b==0) {
		System.out.println(b+"is a factor of:"+a);
	}
	b=0;
	if (b!=0 && a%b==0) {
		System.out.println(b+"is a factor of:"+a);
	}
/*System.out.println("FirstLine\nSecondline");
System.out.println("A\tB\tC");
System.out.println("E\tD\tF");*/
boolean A,B;
System.out.println("A\tB\tAND\tOR\tNOT\tXOR");
A=true;B=true;
System.out.println(A+"\t"+B+"\t"+(A&B)+"\t"+(A|B)+"\t"+(!A)+"\t"+(A^B));
A=true;B=false;
System.out.println(A+"\t"+B+"\t"+(A&B)+"\t"+(A|B)+"\t"+(!A)+"\t"+(A^B));
A=false;B=true;
System.out.println(A+"\t"+B+"\t"+(A&B)+"\t"+(A|B)+"\t"+(!A)+"\t"+(A^B));
A=false;B=false;
System.out.println(A+"\t"+B+"\t"+(A&B)+"\t"+(A|B)+"\t"+(!A)+"\t"+(A^B));

char val;
val='x';
System.out.println(val);
val++;
System.out.println(val);
boolean c;
c=true;
if(c)
System.out.println(10>9);
c=true;
if(c)
System.out.println("10>9");	

for(int i=1;i<=5;i++) {
	System.out.println(i+"Round");
	System.out.println("Done!!");
}
int d=10;
System.out.println(d--);
System.out.println(d);
float euro=.43f;
for(int i=1;i<=100;i++) {
System.out.println(i+"euro is equal to"+i*euro);	
}
double x,y,z;
x=25;
y=25;
z=Math.sqrt(x+y);
System.out.println(z);
short s=12345;
long du;
du=s;
System.out.println(du);
/*String temp; // Temporary storage for input. 
temp = JOptionPane.showInputDialog(null, "First number"); 
int m = Integer.parseInt(temp); // String to integer
temp = JOptionPane.showInputDialog(null, "Second number");
int n = Integer.parseInt(temp); 
temp = JOptionPane.showInputDialog(null, "Third number"); 
int k = Integer.parseInt(temp);
JOptionPane.showMessageDialog(null, "Average is " + (m+n+k)/3); 
*/
String length;
length=JOptionPane.showInputDialog("First Number");
int l=Integer.parseInt(length);
length=JOptionPane.showInputDialog("second Number");
int o=Integer.parseInt(length);
length=JOptionPane.showInputDialog("Third Number");
int p=Integer.parseInt(length);
JOptionPane.showMessageDialog(null,"average is"+(l+o+p)/3);
} 
}


















