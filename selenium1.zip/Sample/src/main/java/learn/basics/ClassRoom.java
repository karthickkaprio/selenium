package learn.basics;

public class ClassRoom {

	public static void main(String[] args) {
		String val= "PAYPAL";
	
	    //char[] set= val.toCharArray();
		String use="P";
		
		
			for(int i=0;i<val.length();i++) {
				if(use.equalsIgnoreCase(val)){
	             use=use+val.charAt(i);
				System.out.println();
				}
			}
				
			
		
//text2.charAt(index)
		
		
		
String  text1= "PAYPAL";
String num=text1.replaceAll("A","");
//int val1=val.length();
int val2=text1.length()-num.length();
System.out.println(val2);
	}
}
	

