package single.inheritance;

public class Department1 extends College1 {
	public void deptname() {
		System.out.println("computer science");
	}
	public void collegeName() {
		System.out.println("polytechnic");
	}

	public void collegeData() {
		super.collegeName();
		
	}

}
