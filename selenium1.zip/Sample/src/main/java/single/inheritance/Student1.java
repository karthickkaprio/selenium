package single.inheritance;

public class Student1 extends Department1 {
	public void studentName() {
		System.out.println("valarmathi");
	}
	public void studentDept() {
		System.out.println("computer science");
	}
	public void studentId() {
		System.out.println("11CS35");
	}
	public void deptName() {
		
	}
   public void collegeData() {
	   super.collegeName();
	   
	   
   }
   public static void main(String[] args) {
	   Student1 obj=new Student1();
	   obj.collegeData();
	   

}
}
