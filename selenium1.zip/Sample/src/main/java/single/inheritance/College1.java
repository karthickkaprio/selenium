package single.inheritance;

public class College1 {
	public void collegeName() {
		System.out.println("FX College");
	}
	public void collegeCode() {
		System.out.println("11111");
	}
	public void collegeRank() {
		System.out.println("25");
	}

}
