package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;


public class ProjectSpecificMethods {
	public static ChromeDriver driver;
	public Properties prop;
	
	
	@BeforeMethod
	public void preCondition() throws IOException {
		
		FileInputStream fis=new FileInputStream("./src/test/resources/English.properties");
	    prop=new Properties();
		prop.load(fis);
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	@AfterMethod
	public void postCondition() {
		driver.close();
	}
	
	
}
