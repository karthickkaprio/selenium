package pages;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public LoginPage clicklogout() {
		driver.findElementByClassName(prop.getProperty("HomePage.Logout.ClassName")).click();
		return new LoginPage();
	}

}
