package pages;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
  public LoginPage enterusername() {
	  driver.findElementById(prop.getProperty("LoginPage.username.Id")).sendKeys("demosalesmanager");
	  return this;
  }
  public LoginPage enterpassword() {
	  driver.findElementById(prop.getProperty("LoginPage.password.Id")).sendKeys("crmsfa");
	  return this;
  }
  public HomePage clicklogin() {
	  driver.findElementByClassName(prop.getProperty("LoginPage.Login.ClassName")).click();
	  return new HomePage();
  }
}
